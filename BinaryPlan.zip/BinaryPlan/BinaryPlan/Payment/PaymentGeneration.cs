﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BinaryPlan.Data;
using log = BinaryPlan.Common;
using System.Data.SqlClient;

namespace BinaryPlan.Payment
{
    public partial class PaymentGeneration : Form
    {
        private const string REGULERINCOMEMESSAGESTART = "Regular Income generation in progress....";
        private const string REGULERINCOMEMESSAGEEND = "Regular Income generation completed.";
        private const string ROYALTYINCOMEMESSAGESTART = "Royalty generation in progress....";
        private const string ROYALTYINCOMEMESSAGEEND = "Royalty generation completed.";
        public PaymentGeneration()
        {
            InitializeComponent();
        }

        /// <summary>
        /// This approach is hard coded for check royalty
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnUpdatePairAndCount_Click(object sender, EventArgs e)
        {
            int leftCount = 0;
            int rightCount = 0;
            //int level = 0;
            int pair = 0;
            int accId = 0;
            using (BPlanEntities ctx = new BPlanEntities())
            {
                var accounts = ctx.Account_Details.ToList();

                foreach (var account in accounts)
                {
                    accId = account.Acc_Id;
                    int Depth = 0;
                    leftCount = account.L_Count;
                    rightCount = account.R_Count;
                    pair = Convert.ToInt16(account.Pair);

                    int count = CountNodes(account);

                    bool IsEleigilbleForSilverRoyalty = checkSilverPair(account.Acc_Id);
                    var SilverIncome = ctx.Income_Type.Where(x => x.IncomeId == 5).FirstOrDefault();
                    if (SilverIncome != null && IsEleigilbleForSilverRoyalty)
                        ctx.Royalty_Detail.Add(new Royalty_Detail() { Acc_Id = account.Acc_Id, IncomeId = SilverIncome.IncomeId, RoyaltyQualifyDate = DateTime.Now, TotalPairs = pair });

                    if (IsEleigilbleForSilverRoyalty)
                    {
                        bool IsEleigilbleForGoldRoyalty = checkGoldPair(account.Acc_Id);
                        var GoldIncome = ctx.Income_Type.Where(x => x.IncomeId == 6).FirstOrDefault();
                        if (GoldIncome != null && IsEleigilbleForGoldRoyalty)
                            ctx.Royalty_Detail.Add(new Royalty_Detail() { Acc_Id = account.Acc_Id, IncomeId = GoldIncome.IncomeId, RoyaltyQualifyDate = DateTime.Now, TotalPairs = pair });
                    }

                    //Check Diamond Royalty
                    //TODO:Yet  to code

                    ctx.SaveChanges();
                }

            }

            using (BPlanEntities ctxPay = new BPlanEntities())
            {

                //Calculate Payment for all the silver and gold/Diamond


            }

            MessageBox.Show("Done");
        }

        #region comment

        //int maxDepth(Account_Details node)
        //{
        //    if (node == null || node.Acc_Id == 0)
        //    {
        //        return (0);
        //    }
        //    else
        //    {
        //        using (BPlanEntities ctx = new BPlanEntities())
        //        {
        //            // compute the depth of each subtree                     
        //            int lDepth = maxDepth(ctx.Account_Details.Where(x => x.Acc_Id == node.Left_Id).FirstOrDefault());
        //            int rDepth = maxDepth(ctx.Account_Details.Where(x => x.Acc_Id == node.Right_Id).FirstOrDefault());
        //            // use the larger one 
        //            if (lDepth > rDepth) return (lDepth + 1);
        //            else return (rDepth + 1);
        //        }
        //    }
        //}

        //int maxDepthIterative(Account_Details root)
        //{
        //    using (BPlanEntities ctx = new BPlanEntities())
        //    {
        //        if (root == null) return 0;
        //        Stack<Account_Details> s = new Stack<Account_Details>();
        //        s.Push(root);
        //        int maxDepth = 0;
        //        Account_Details prev = null;
        //        while (!(s.Count == 0))
        //        {
        //            Account_Details curr = s.Peek();
        //            if (prev != null || prev.Left_Id == curr.Acc_Id || prev.Right_Id == curr.Acc_Id)
        //            {
        //                if (curr.Left_Id != 0)
        //                    s.Push(ctx.Account_Details.Where(x => x.Acc_Id == curr.Left_Id).FirstOrDefault());
        //                else if (curr.Right_Id != 0)
        //                    s.Push(ctx.Account_Details.Where(x => x.Acc_Id == curr.Right_Id).FirstOrDefault());
        //            }
        //            else if (curr.Left_Id == prev.Acc_Id)
        //            {
        //                if (curr.Right_Id != 0)
        //                    s.Push(ctx.Account_Details.Where(x => x.Acc_Id == curr.Right_Id).FirstOrDefault());
        //            }
        //            else
        //            {
        //                s.Pop();
        //            }
        //            prev = curr;
        //            if (s.Count() > maxDepth)
        //                maxDepth = s.Count();
        //        }
        //        return maxDepth;
        //    }
        //}

        //int DepthOfAccount(Account_Details root)
        //{
        //    using (BPlanEntities ctx = new BPlanEntities())
        //    {
        //        if (root == null) return 0;
        //        Stack<Account_Details> s = new Stack<Account_Details>();
        //        s.Push(root);
        //        int maxDepth = 0;
        //        int level = 0;
        //        //Account_Details prev = null;
        //        while (!(s.Count == 0))
        //        {
        //            Account_Details curr = s.Peek();
        //            if (curr != null && (curr.Left_Id != 0))
        //            {
        //                level++;
        //                if (level <= 3)
        //                {
        //                    var Lacc = ctx.Account_Details.Where(x => x.Acc_Id == curr.Left_Id).FirstOrDefault();
        //                    if (Lacc != null)
        //                        s.Push(Lacc);
        //                }
        //            }
        //            else if (curr != null && (curr.Right_Id != 0))
        //            {
        //                var Racc = ctx.Account_Details.Where(x => x.Acc_Id == curr.Right_Id).FirstOrDefault();
        //                if (Racc != null)
        //                    s.Push(Racc);
        //            }
        //            else
        //            {
        //                s.Pop();
        //            }

        //            if (s.Count() > 0)
        //                maxDepth = s.Count();
        //            else
        //                maxDepth = 0;

        //        }

        //        return maxDepth;
        //    }


        //}

        #endregion

        /// <summary>
        /// This is to count the number of Nodes
        /// </summary>
        /// <param name="root"></param>
        /// <returns></returns>
        int CountNodes(Account_Details root)
        {
            using (BPlanEntities ctx = new BPlanEntities())
            {
                int count = 1;
                if (root.Left_Id != 0)
                {
                    var lacc = ctx.Account_Details.Where(x => x.Acc_Id == root.Left_Id).FirstOrDefault();
                    if (lacc != null)
                        count += CountNodes(lacc);
                }
                if (root.Right_Id != 0)
                {
                    var racc = ctx.Account_Details.Where(x => x.Acc_Id == root.Right_Id).FirstOrDefault();
                    count += CountNodes(racc);
                }
                return count;

            }
        }

        /// <summary>
        /// This method is used to check silver royalty eligibility
        /// </summary>
        /// <param name="accountId"></param>
        /// <returns></returns>
        bool checkSilverPair(int accountId)
        {
            int countLevel = 0;
            int pairCount = 0;
            int loopBreak = 0;
            List<LevelPairCount> levelPairCount = new List<LevelPairCount>();
            for (int i = 0; i < 3; i++)
            {
                if (loopBreak == -1)
                {
                    break;
                }
                using (BPlanEntities ctx = new BPlanEntities())
                {
                    var acc = ctx.Account_Details.Where(x => x.Acc_Id == accountId).FirstOrDefault();

                    switch (i)
                    {

                        case 0:
                            pairCount = 0;
                            if (acc.Left_Id != 0 && acc.Right_Id != 0)
                            {
                                pairCount++;

                            }
                            else
                            {
                                loopBreak = -1;
                            }
                            countLevel++;
                            levelPairCount.Add(new LevelPairCount() { AccId = accountId, LevelCount = countLevel, PairCount = pairCount });
                            break;

                        case 1:
                            pairCount = 0;
                            var lacc = ctx.Account_Details.Where(x => x.Acc_Id == acc.Left_Id).FirstOrDefault();
                            var racc = ctx.Account_Details.Where(x => x.Acc_Id == acc.Right_Id).FirstOrDefault();
                            if (lacc != null && lacc.Left_Id != 0 && lacc.Right_Id != 0)
                            {
                                pairCount++;
                            }
                            else
                            {
                                loopBreak = -1;
                            }

                            if (racc != null && racc.Left_Id != 0 && racc.Right_Id != 0)
                            {
                                pairCount++;
                            }
                            else
                            {
                                loopBreak = -1;
                            }
                            countLevel++;
                            levelPairCount.Add(new LevelPairCount() { AccId = accountId, LevelCount = countLevel, PairCount = pairCount });
                            break;
                        case 2:
                            pairCount = 0;
                            var lacc2 = ctx.Account_Details.Where(x => x.Acc_Id == acc.Left_Id).FirstOrDefault();
                            var racc2 = ctx.Account_Details.Where(x => x.Acc_Id == acc.Right_Id).FirstOrDefault();

                            var lacc21 = ctx.Account_Details.Where(x => x.Acc_Id == lacc2.Left_Id).FirstOrDefault();
                            var lacc22 = ctx.Account_Details.Where(x => x.Acc_Id == lacc2.Right_Id).FirstOrDefault();

                            var racc21 = ctx.Account_Details.Where(x => x.Acc_Id == racc2.Left_Id).FirstOrDefault();
                            var racc22 = ctx.Account_Details.Where(x => x.Acc_Id == racc2.Right_Id).FirstOrDefault();


                            if (lacc21 != null && lacc21.Left_Id != 0 && lacc21.Right_Id != 0)
                            {
                                pairCount++;
                            }
                            else
                            {
                                loopBreak = -1;
                            }

                            if (lacc22 != null && lacc22.Left_Id != 0 && lacc22.Right_Id != 0)
                            {
                                pairCount++;
                            }
                            else
                            {
                                loopBreak = -1;
                            }

                            if (racc21 != null && racc21.Left_Id != 0 && racc21.Right_Id != 0)
                            {
                                pairCount++;
                            }
                            else
                            {
                                loopBreak = -1;
                            }

                            if (racc22 != null && racc22.Left_Id != 0 && racc22.Right_Id != 0)
                            {
                                pairCount++;
                            }
                            else
                            {
                                loopBreak = -1;
                            }
                            countLevel++;
                            levelPairCount.Add(new LevelPairCount() { AccId = accountId, LevelCount = countLevel, PairCount = pairCount });
                            break;


                        default:
                            pairCount = 0;
                            break;
                    }

                }
            }
            bool isSilverQualify = false;
            foreach (var levelPair in levelPairCount)
            {
                if (levelPair.LevelCount == 3 && levelPair.PairCount == 4)
                    isSilverQualify = true;

                UpdateLevelPairs(levelPair.AccId, levelPair.LevelCount, levelPair.PairCount);
            }

            if (isSilverQualify)
                return true;
            else
                return false;
        }

        /// <summary>
        /// This method is used to check gold eligibilty
        /// </summary>
        /// <param name="accountId"></param>
        /// <returns></returns>
        bool checkGoldPair(int accountId)
        {
            int countLevel = 0;
            int pairCount = 0;
            int loopBreak = 0;
            List<LevelPairCount> levelPairCount = new List<LevelPairCount>();
            for (int i = 0; i <= 3; i++)
            {
                if (loopBreak == -1)
                {
                    break;
                }
                using (BPlanEntities ctx = new BPlanEntities())
                {
                    var acc = ctx.Account_Details.Where(x => x.Acc_Id == accountId).FirstOrDefault();

                    switch (i)
                    {

                        case 0:
                            pairCount = 0;
                            if (acc.Left_Id != 0 && acc.Right_Id != 0)
                            {
                                countLevel++;
                                pairCount++;

                                levelPairCount.Add(new LevelPairCount() { AccId = accountId, LevelCount = countLevel, PairCount = pairCount });
                            }
                            else
                            {
                                loopBreak = -1;
                            }
                            break;

                        case 1:
                            pairCount = 0;
                            var lacc = ctx.Account_Details.Where(x => x.Acc_Id == acc.Left_Id).FirstOrDefault();
                            var racc = ctx.Account_Details.Where(x => x.Acc_Id == acc.Right_Id).FirstOrDefault();
                            if (lacc != null && lacc.Left_Id != 0 && lacc.Right_Id != 0)
                            {
                                pairCount++;
                            }
                            else
                            {
                                loopBreak = -1;
                            }

                            if (racc != null && racc.Left_Id != 0 && racc.Right_Id != 0)
                            {
                                pairCount++;
                            }
                            else
                            {
                                loopBreak = -1;
                            }
                            countLevel++;
                            levelPairCount.Add(new LevelPairCount() { AccId = accountId, LevelCount = countLevel, PairCount = pairCount });
                            break;
                        case 2:
                            pairCount = 0;
                            var lacc2 = ctx.Account_Details.Where(x => x.Acc_Id == acc.Left_Id).FirstOrDefault();
                            var racc2 = ctx.Account_Details.Where(x => x.Acc_Id == acc.Right_Id).FirstOrDefault();

                            var lacc21 = ctx.Account_Details.Where(x => x.Acc_Id == lacc2.Left_Id).FirstOrDefault();
                            var lacc22 = ctx.Account_Details.Where(x => x.Acc_Id == lacc2.Right_Id).FirstOrDefault();

                            var racc21 = ctx.Account_Details.Where(x => x.Acc_Id == racc2.Left_Id).FirstOrDefault();
                            var racc22 = ctx.Account_Details.Where(x => x.Acc_Id == racc2.Right_Id).FirstOrDefault();


                            if (lacc21 != null && lacc21.Left_Id != 0 && lacc21.Right_Id != 0)
                            {
                                pairCount++;
                            }
                            else
                            {
                                loopBreak = -1;
                            }

                            if (lacc22 != null && lacc22.Left_Id != 0 && lacc22.Right_Id != 0)
                            {
                                pairCount++;
                            }
                            else
                            {
                                loopBreak = -1;
                            }

                            if (racc21 != null && racc21.Left_Id != 0 && racc21.Right_Id != 0)
                            {
                                pairCount++;
                            }
                            else
                            {
                                loopBreak = -1;
                            }

                            if (racc22 != null && racc22.Left_Id != 0 && racc22.Right_Id != 0)
                            {
                                pairCount++;
                            }
                            else
                            {
                                loopBreak = -1;
                            }
                            countLevel++;
                            levelPairCount.Add(new LevelPairCount() { AccId = accountId, LevelCount = countLevel, PairCount = pairCount });
                            break;
                        case 3:
                            pairCount = 0;
                            var lacc3 = ctx.Account_Details.Where(x => x.Acc_Id == acc.Left_Id).FirstOrDefault();
                            var racc3 = ctx.Account_Details.Where(x => x.Acc_Id == acc.Right_Id).FirstOrDefault();

                            var lacc31 = ctx.Account_Details.Where(x => x.Acc_Id == lacc3.Left_Id).FirstOrDefault();
                            var lacc32 = ctx.Account_Details.Where(x => x.Acc_Id == lacc3.Right_Id).FirstOrDefault();

                            var racc31 = ctx.Account_Details.Where(x => x.Acc_Id == racc3.Left_Id).FirstOrDefault();
                            var racc32 = ctx.Account_Details.Where(x => x.Acc_Id == racc3.Right_Id).FirstOrDefault();

                            var lacc311 = ctx.Account_Details.Where(x => x.Acc_Id == lacc31.Left_Id).FirstOrDefault();
                            var lacc312 = ctx.Account_Details.Where(x => x.Acc_Id == lacc31.Right_Id).FirstOrDefault();

                            var lacc321 = ctx.Account_Details.Where(x => x.Acc_Id == lacc32.Left_Id).FirstOrDefault();
                            var lacc322 = ctx.Account_Details.Where(x => x.Acc_Id == lacc32.Right_Id).FirstOrDefault();

                            var racc311 = ctx.Account_Details.Where(x => x.Acc_Id == racc31.Left_Id).FirstOrDefault();
                            var racc312 = ctx.Account_Details.Where(x => x.Acc_Id == racc31.Right_Id).FirstOrDefault();

                            var racc321 = ctx.Account_Details.Where(x => x.Acc_Id == racc32.Left_Id).FirstOrDefault();
                            var racc322 = ctx.Account_Details.Where(x => x.Acc_Id == racc32.Right_Id).FirstOrDefault();


                            if (lacc311 != null && lacc311.Left_Id != 0 && lacc311.Right_Id != 0)
                            {
                                pairCount++;
                            }
                            else
                            {
                                loopBreak = -1;
                            }

                            if (lacc312 != null && lacc312.Left_Id != 0 && lacc312.Right_Id != 0)
                            {
                                pairCount++;
                            }
                            else
                            {
                                loopBreak = -1;
                            }

                            if (lacc321 != null && lacc321.Left_Id != 0 && lacc321.Right_Id != 0)
                            {
                                pairCount++;
                            }
                            else
                            {
                                loopBreak = -1;
                            }

                            if (lacc322 != null && lacc322.Left_Id != 0 && lacc322.Right_Id != 0)
                            {
                                pairCount++;
                            }
                            else
                            {
                                loopBreak = -1;
                            }

                            if (racc311 != null && racc311.Left_Id != 0 && racc311.Right_Id != 0)
                            {
                                pairCount++;
                            }
                            else
                            {
                                loopBreak = -1;
                            }

                            if (racc312 != null && racc312.Left_Id != 0 && racc312.Right_Id != 0)
                            {
                                pairCount++;
                            }
                            else
                            {
                                loopBreak = -1;
                            }

                            if (racc321 != null && racc321.Left_Id != 0 && racc321.Right_Id != 0)
                            {
                                pairCount++;
                            }
                            else
                            {
                                loopBreak = -1;
                            }


                            if (racc322 != null && racc322.Left_Id != 0 && racc322.Right_Id != 0)
                            {
                                pairCount++;
                            }
                            else
                            {
                                loopBreak = -1;
                            }

                            countLevel++;
                            levelPairCount.Add(new LevelPairCount() { AccId = accountId, LevelCount = countLevel, PairCount = pairCount });
                            break;

                        default:
                            break;
                    }

                }
            }

            bool isGoldQualify = false;

            foreach (var levelPair in levelPairCount)
            {
                if (levelPair.LevelCount == 4 && levelPair.PairCount == 8)
                    isGoldQualify = true;

                UpdateLevelPairs(levelPair.AccId, levelPair.LevelCount, levelPair.PairCount);
            }

            if (isGoldQualify)
                return true;
            else
                return false;
        }

        public void UpdateLevelPairs(int AccountId, int Level, int TotalPair)
        {
            using (BPlanEntities ctx = new BPlanEntities())
            {
                var AccountExist = ctx.Account_Pair_Details.Where(x => x.AccId == AccountId && x.TreeLevel == Level).FirstOrDefault();

                if (AccountExist == null)
                {
                    ctx.Account_Pair_Details.Add(new Account_Pair_Details()
                    {
                        AccId = AccountId,
                        TreeLevel = Level,
                        PairCount = TotalPair,
                        UpdateDate = DateTime.Now
                    });


                }
                else
                {
                    //AccountExist.TreeLevel = Level;
                    AccountExist.PairCount = TotalPair;
                    AccountExist.UpdateDate = DateTime.Now;
                    ctx.Entry(AccountExist).State = System.Data.Entity.EntityState.Modified;
                }


                ctx.SaveChanges();
            }
        }

        private void btnCreatePaymentSession_Click(object sender, EventArgs e)
        {
            //Validate Session before create
            List<string> validationMessage = new List<string>();
            if (string.IsNullOrEmpty(txtPaymentSessionName.Text))
            {
                validationMessage.Add("Please enter session Name!");
            }
            Guid txnId = Guid.NewGuid();
            int paySessionId = 0;
            using (BPlanEntities ctx = new BPlanEntities())
            {

                using (System.Data.Entity.DbContextTransaction dbTran = ctx.Database.BeginTransaction())
                {
                    try
                    {
                        //check existing session and then create new
                        //ctx.

                        var paySession = ctx.PaymentSessions.Where(x => x.PaymentSessionEndDate != null).OrderByDescending(x => x.PaymentSessionId).FirstOrDefault();

                        if (paySession != null && !(dtpPaymentStartDate.Value >= paySession.PaymentSessionEndDate))
                        {
                            ValidationMessage("Select Date greater than or equal to " + paySession.PaymentSessionEndDate);
                            return;
                        }
                        PaymentSession paymentSession = new PaymentSession();
                        paymentSession.PaymentSessionName = txtPaymentSessionName.Text;
                        paymentSession.PaymentSessionStartDate = dtpPaymentStartDate.Value;
                        paymentSession.TxnId = txnId.ToString().ToUpper();
                        ctx.PaymentSessions.Add(paymentSession);
                        ctx.SaveChanges();


                        paySessionId = paymentSession.PaymentSessionId;


                        dbTran.Commit();

                        MessageBox.Show("Session Created & payment generated successfully !!");
                    }
                    catch (Exception ex)
                    {
                        dbTran.Rollback();
                        log.Logger.Log(ex.Message, ex.StackTrace);
                        MessageBox.Show("Session Creation failed!");
                    }
                }
            }

            GeneratePayment(dtpPaymentStartDate.Value, DateTime.Now, paySessionId, txnId.ToString());
        }

        public void ValidationMessage(string message)
        {
            MessageBox.Show(message);
        }



        List<string> lstNodes = new List<string>();
        /// <summary>
        /// This is perfect method for count node at level and pair
        /// </summary>
        /// <param name="tree"></param>
        /// <param name="level"></param>
        public void printGivenLevel(int tree, int level)
        {

            using (BPlanEntities ctx = new BPlanEntities())
            {
                if (tree == 0)
                    return;

                if (level == 1)
                    lstNodes.Add(tree.ToString());
                else if (level > 1)
                {
                    var pnode = ctx.Account_Details.Where(x => x.Acc_Id == tree).FirstOrDefault();
                    var lnode = ctx.Account_Details.Where(x => x.Acc_Id == pnode.Left_Id).FirstOrDefault();
                    var rnode = ctx.Account_Details.Where(x => x.Acc_Id == pnode.Right_Id).FirstOrDefault();
                    if (pnode != null)
                    {
                        printGivenLevel(pnode.Left_Id.Value, level - 1);
                        printGivenLevel(pnode.Right_Id.Value, level - 1);
                    }
                }
            }


        }

        /// <summary>
        /// This approiach is dynamic approach for check royalty
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCheckPairs_Click(object sender, EventArgs e)
        {
            Guid txnId = Guid.NewGuid();

            //Generate RegularIncome Before Calculate Royalty
            generateRegularIncome(txnId);

            //Calculate Royalty
            GenerateAllRoyalty(txnId);
        }

        private void GenerateAllRoyalty(Guid txnId)
        {
            lblStatusPaymentGenration.Text = ROYALTYINCOMEMESSAGESTART;
            using (BPlanEntities ctx = new BPlanEntities())
            {
                using (System.Data.Entity.DbContextTransaction dbTran = ctx.Database.BeginTransaction())
                {
                    try
                    {

                        var Accounts = ctx.Account_Details.Where(x => x.Left_Id != null || x.Right_Id != null).ToList();
                        PaymentGenerationProgressbar.Minimum = 0;

                        int count = 0;
                        foreach (var account in Accounts)
                        {
                            PaymentGenerationProgressbar.Maximum = Accounts.Count;
                            PaymentGenerationProgressbar.Value = count++;
                            bool isQualifySilver = false;
                            bool isQualifyGold = false;
                            printGivenLevel(account.Acc_Id, 4);
                            if (lstNodes.Count % 2 == 0)
                            {
                                int totalpairs = lstNodes.Count / 2;
                                if (totalpairs >= 4)
                                {
                                    isQualifySilver = true;
                                    var SilverIncome = ctx.Income_Type.Where(x => x.IncomeId == 5).FirstOrDefault();
                                    if (SilverIncome != null)
                                        ctx.Royalty_Detail.Add(new Royalty_Detail() { Acc_Id = account.Acc_Id, IncomeId = SilverIncome.IncomeId, RoyaltyQualifyDate = DateTime.Now, TotalPairs = totalpairs, TxnId = txnId.ToString().ToUpper() });

                                }
                            }
                            lstNodes.Clear();


                            if (isQualifySilver)
                            {
                                printGivenLevel(account.Acc_Id, 5);
                                if (lstNodes.Count % 2 == 0)
                                {
                                    int totalpairs = lstNodes.Count / 2;
                                    if (totalpairs >= 8)
                                    {
                                        isQualifyGold = true;
                                        var GoldIncome = ctx.Income_Type.Where(x => x.IncomeId == 6).FirstOrDefault();
                                        if (GoldIncome != null)
                                            ctx.Royalty_Detail.Add(new Royalty_Detail() { Acc_Id = account.Acc_Id, IncomeId = GoldIncome.IncomeId, RoyaltyQualifyDate = DateTime.Now, TotalPairs = totalpairs, TxnId = txnId.ToString().ToUpper() });

                                    }
                                }
                                lstNodes.Clear();
                            }


                            if (isQualifyGold)
                            {
                                printGivenLevel(account.Acc_Id, 6);
                                if (lstNodes.Count % 2 == 0)
                                {
                                    int totalpairs = lstNodes.Count / 2;
                                    if (totalpairs >= 16)
                                    {
                                        var diamondIncome = ctx.Income_Type.Where(x => x.IncomeId == 6).FirstOrDefault();
                                        if (diamondIncome != null)
                                            ctx.Royalty_Detail.Add(new Royalty_Detail() { Acc_Id = account.Acc_Id, IncomeId = diamondIncome.IncomeId, RoyaltyQualifyDate = DateTime.Now, TotalPairs = totalpairs, TxnId = txnId.ToString().ToUpper() });

                                    }
                                }
                                lstNodes.Clear();
                            }
                        }
                        ctx.SaveChanges();
                        dbTran.Commit();
                        PaymentGenerationProgressbar.Value = 0;
                        lblStatusPaymentGenration.Text = ROYALTYINCOMEMESSAGEEND;
                    }
                    catch (Exception ex)
                    {
                        log.Logger.Log("TXNID : " + txnId + " " + ex.Message, ex.StackTrace);
                        dbTran.Rollback();
                    }
                }
            }
        }

        public void CountPairsAtLevel(int AccId, int level)
        {
            List<string> lstNodes = new List<string>();
            using (BPlanEntities ctx = new BPlanEntities())
            {
                if (AccId == 0)
                    return;

                if (level == 1)
                    lstNodes.Add(AccId.ToString());
                else if (level > 1)
                {
                    var pnode = ctx.Account_Details.Where(x => x.Acc_Id == AccId).FirstOrDefault();
                    var lnode = ctx.Account_Details.Where(x => x.Acc_Id == pnode.Left_Id).FirstOrDefault();
                    var rnode = ctx.Account_Details.Where(x => x.Acc_Id == pnode.Right_Id).FirstOrDefault();
                    if (pnode != null)
                    {
                        printGivenLevel(pnode.Left_Id.Value, level - 1);
                        printGivenLevel(pnode.Right_Id.Value, level - 1);
                    }
                }
            }
        }

        public bool CheckPaymentFreequency(string payFreequency, DateTime start, DateTime end)
        {
            bool isCorrectDateDiff = false;
            switch (payFreequency.ToLower())
            {
                case "week":
                    double totalDayDiffWeek = (end - start).TotalDays;
                    if (totalDayDiffWeek >= 7)
                        isCorrectDateDiff = true;
                    break;
                case "month":
                    double totalDayDiffMonth = (end - start).TotalDays;
                    if (totalDayDiffMonth >= 30)
                        isCorrectDateDiff = true;
                    break;
                case "year":
                    double totalDayDiffYear = (end - start).TotalDays;
                    if (totalDayDiffYear >= 365)
                        isCorrectDateDiff = true;
                    break;
                default:
                    break;
            }

            return isCorrectDateDiff;
        }

        /// <summary>
        /// This method is used to generate payment for start and end date. Start date should be always selected greater then last session end date.
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="paymentSessionId"></param>
        public void GeneratePayment(DateTime startDate, DateTime endDate, int paymentSessionId, string txnId)
        {
            using (BPlanEntities ctx = new BPlanEntities())
            {
                string payFreequency = string.Empty;
                var paymentFreequency = ctx.Settings.Where(x => x.SettingKey == "PaymentFreequency").FirstOrDefault();
                if (paymentFreequency != null)
                    payFreequency = paymentFreequency.SettingValue.ToString();

                if (CheckPaymentFreequency(payFreequency, startDate, endDate))
                {
                    using (System.Data.Entity.DbContextTransaction dbTran = ctx.Database.BeginTransaction())
                    {
                        try
                        {
                            var lstAccount = ctx.Account_Details.Where(x => (x.Left_Id != null && x.Left_Id != 0) && (x.Right_Id != null && x.Right_Id != 0)).ToList();

                            foreach (var account in lstAccount)
                            {
                                List<GetIncomeDetails_Result> incomeDetails = GetIncomeDetail(account.Acc_Id, startDate, endDate);
                                foreach (var income in incomeDetails)
                                {

                                    //Update payment detail with sesion Id
                                    PaymentDetail paymentDetail = ctx.PaymentDetails.Where(x => x.Acc_Id == account.Acc_Id && x.IncomeTypeId == income.IncomeTypeId).FirstOrDefault();
                                    if (paymentDetail != null)
                                    {
                                        paymentDetail.PaymentSessionId = paymentSessionId;
                                        ctx.Entry(paymentDetail).State = System.Data.Entity.EntityState.Modified;
                                        ctx.PaymentDetails.Add(paymentDetail);
                                        ctx.SaveChanges();
                                    }

                                    Payment_master paymentMaster = new Data.Payment_master();
                                    paymentMaster.Acc_Id = account.Acc_Id;
                                    paymentMaster.Amount = income.Amount;
                                    paymentMaster.Income_Type = income.IncomeTypeId;
                                    paymentMaster.IsPaymentProcessed = false;
                                    paymentMaster.PaymentSessionId = paymentSessionId;
                                    paymentMaster.PayGenerateTxnId = txnId.ToString().ToUpper();
                                    ctx.Payment_master.Add(paymentMaster);
                                    ctx.SaveChanges();


                                }
                            }

                            PaymentSession paymentSession = ctx.PaymentSessions.Where(x => x.PaymentSessionId == paymentSessionId).FirstOrDefault();
                            if (paymentSession != null)
                            {
                                paymentSession.PaymentSessionEndDate = endDate;
                                paymentSession.PaymentFreequency = payFreequency;
                                ctx.PaymentSessions.Add(paymentSession);
                                ctx.Entry(paymentSession).State = System.Data.Entity.EntityState.Modified;
                                ctx.SaveChanges();
                            }




                            dbTran.Commit();

                            var allPaymentDetailProcessed = ctx.PaymentDetails.Where(x => x.PaymentSessionId == paymentSessionId).ToList();

                            foreach (var paymentDetailProcess in allPaymentDetailProcessed)
                            {
                                paymentDetailProcess.IsPaymentProcessed = true;
                                ctx.Entry(paymentDetailProcess).State = System.Data.Entity.EntityState.Modified;
                                ctx.PaymentDetails.Add(paymentDetailProcess);
                                ctx.SaveChanges();
                            }

                            MessageBox.Show("Payment Generated Successfully! for Period start from :" + startDate + "  To " + endDate);

                        }
                        catch (Exception ex)
                        {
                            dbTran.Rollback();
                            log.Logger.Log(ex.Message, ex.StackTrace);
                            MessageBox.Show("Session Creation failed!");
                        }
                    }
                }
                else
                {
                    log.Logger.Log("Payment Freequency does not matched with dates passed in session for generate payment. Correct dates for generate payment. ", string.Empty);
                    MessageBox.Show("Session Creation failed! Due to date differtence correct date should be passed for payment generate.");
                }
            }
        }

        public List<GetIncomeDetails_Result> GetIncomeDetail(int accid, DateTime startDate, DateTime endDate)
        {
            using (DataAccess _dataAccess = new DataAccess())
            {
                List<GetIncomeDetails_Result> lstIncome = new List<GetIncomeDetails_Result>();
                lstIncome.Clear();

                SqlParameter[] paraArr = new SqlParameter[4];
                paraArr[0] = new SqlParameter("@AccId", accid);
                paraArr[0].DbType = DbType.Int16;
                paraArr[0].Direction = ParameterDirection.Input;

                paraArr[1] = new SqlParameter("@StartDate", startDate);
                paraArr[1].DbType = DbType.DateTime;
                paraArr[1].Direction = ParameterDirection.Input;

                paraArr[2] = new SqlParameter("@EndDate", endDate);
                paraArr[2].DbType = DbType.DateTime;
                paraArr[2].Direction = ParameterDirection.Input;

                paraArr[3] = new SqlParameter("@IsPaymentProcessed ", false);
                paraArr[3].DbType = DbType.Boolean;
                paraArr[3].Direction = ParameterDirection.Input;

                DataSet dsincome = _dataAccess.FillDataSP("GetIncomeDetails", paraArr);

                foreach (DataRow dr in dsincome.Tables[0].Rows)
                {
                    GetIncomeDetails_Result incomeResult = new GetIncomeDetails_Result();
                    incomeResult.Acc_Id = Convert.ToInt16(dr["Acc_Id"]);
                    incomeResult.Amount = Convert.ToDecimal(dr["Amount"]);
                    incomeResult.IncomeTypeId = Convert.ToInt16(dr["IncomeTypeId"]);
                    incomeResult.Total = Convert.ToDecimal(dr["Total"]);
                    lstIncome.Add(incomeResult);
                }

                return lstIncome;
            }
        }


        public void generateRegularIncome(Guid txnId)
        {
            lblStatusPaymentGenration.Text = REGULERINCOMEMESSAGESTART;

            using (BPlanEntities ctx = new BPlanEntities())
            {
                using (System.Data.Entity.DbContextTransaction dbTran = ctx.Database.BeginTransaction())
                {
                    try
                    {
                        var accounts = ctx.Account_Details.Where(x => x.L_Count != 0 && x.R_Count != 0).ToList();
                        int count = 0;
                        foreach (var account in accounts)
                        {
                            PaymentGenerationProgressbar.Maximum = accounts.Count;
                            PaymentGenerationProgressbar.Value = count++;

                            int leftCount = account.L_Count;
                            int rightCount = account.R_Count;

                            int pair = GetPairFromLRCountUpdated(leftCount, rightCount);
                            int oldPair = account.Old_Pair.HasValue ? Convert.ToInt16(account.Old_Pair) : 0;

                            if (pair != 0)
                            {
                                int totalPair = pair - oldPair;

                                if (totalPair != 0)
                                {
                                    //int TotalIDTopayIncome = totalPair * 4;

                                    decimal totalRegularIncome = 0;

                                    var regularIncome = ctx.Income_Type.Where(x => x.IncomeId == 4).FirstOrDefault();

                                    if (regularIncome != null)
                                    {
                                        totalRegularIncome = totalPair * regularIncome.BasicAmount.Value;
                                    }


                                    ctx.PaymentDetails.Add(new PaymentDetail()
                                    {
                                        Acc_Id = account.Acc_Id,
                                        Amount = totalRegularIncome,
                                        IncomeTypeId = regularIncome.IncomeId,
                                        PaymentDate = DateTime.Now,
                                        TxnId = txnId.ToString().ToUpper()
                                    });
                                    ctx.SaveChanges();

                                    using (BPlanEntities updateCtx = new BPlanEntities())
                                    {
                                        var accDetail = updateCtx.Account_Details.Where(x => x.AccD_Id == account.AccD_Id).FirstOrDefault();

                                        if (accDetail != null)
                                        {
                                            accDetail.Old_Pair = totalPair;
                                            updateCtx.Entry(accDetail).State = System.Data.Entity.EntityState.Modified;
                                            //updateCtx.Account_Details.Add(accDetail);
                                            updateCtx.SaveChanges();
                                        }
                                    }


                                }

                                //Get Income Detail for regular Income

                                // Add in Payment Detail

                                //Update old pair in account details 

                            }

                        }

                        dbTran.Commit();
                        lblStatusPaymentGenration.Text = REGULERINCOMEMESSAGEEND;
                        PaymentGenerationProgressbar.Value = 0;
                    }
                    catch (Exception ex)
                    {
                        dbTran.Rollback();
                        log.Logger.Log(ex.Message, ex.StackTrace);
                        MessageBox.Show("We found some issue in Regular Income Generation please try again !");
                    }
                }
            }

        }

        private int GetPairFromLRCount(int lcount, int rcount)
        {
            int totalPair = 0;

            // 3 < 4
            if (lcount < rcount)
            {
                int divLeft = 0;
                //This become pair in case remright is 0
                int divRight = rcount / 3;

                int remRight = rcount % 3;

                int remLeft = lcount - divRight;

                if (remRight != 0)
                {
                    divLeft = remLeft / 3;

                    int remFinalLeft = remLeft % 3;

                    int remFinalRight = remRight - divLeft;
                }

                totalPair = divRight + divLeft;
            }
            else if (lcount > rcount)
            {
                int divRight = 0;
                //This become pair in case remright is 0
                int divLeft = lcount / 3;

                int remLeft = lcount % 3;

                int remRight = rcount - divLeft;

                if (remLeft != 0)
                {
                    divRight = remRight / 3;

                    int remFinalRight = remRight % 3;

                    int remFinalLeft = remLeft - divRight;
                }

                totalPair = divLeft + divRight;
            }
            else if (lcount == rcount)
            {
                int divRight = rcount / 3;

                int remRight = rcount % 3;

                int remLeft = lcount - divRight;

                if (remRight != 0)
                {
                    int divLeft = remLeft / 3;

                    int remFinalLeft = remLeft % 3;

                    int remFinalRight = remRight - divLeft;

                    if (divLeft != 0)
                    {

                        divRight = divRight + divLeft;
                    }
                }

                totalPair = divRight;
            }

            //Update this count in oldpair and less while next time count pair
            return totalPair;
        }

        private void btnCheckRegularIncomeLogic_Click(object sender, EventArgs e)
        {
            int rcount = Convert.ToInt16(txtRCount.Text);
            int lcount = Convert.ToInt16(txtLCount.Text);


            txtTotalPair.Text = Convert.ToString(GetPairFromLRCountUpdated(lcount, rcount));
        }


        private int GetPairFromLRCountUpdated(int lcount, int rcount)
        {
            int totalPair = 0;

            // 3 < 4
            if (lcount < rcount)
            {
                totalPair = CountPairWhenRCountBig(lcount, rcount, totalPair);
            }
            else if (lcount > rcount)
            {
                totalPair = CountPairWhenLCountBig(lcount, rcount, totalPair);
            }
            else if (lcount == rcount)
            {
                int divRight = rcount / 3;

                int remRight = rcount % 3;

                int remLeft = lcount - divRight;

                if (remRight > remLeft)
                {

                    totalPair = CountPairWhenRCountBigFromEqual(remLeft, remRight, totalPair);
                }
                else
                {
                    totalPair = CountPairWhenLCountBigFromEqual(remLeft, remRight, totalPair);
                }

                //if (remRight != 0)
                //{
                //    int divLeft = remLeft / 3;

                //    int remFinalLeft = remLeft % 3;

                //    int remFinalRight = remRight - divLeft;

                //    if (divLeft != 0)
                //    {

                //        divRight = divRight + divLeft;
                //    }
                //}

                totalPair = totalPair + divRight;
            }

            //Update this count in oldpair and less while next time count pair
            return totalPair;
        }

        private static int CountPairWhenLCountBig(int lcount, int rcount, int totalPair)
        {
            if (lcount > 0 && rcount > 0)
            {
                int divRight = 0;
                //This become pair in case remright is 0
                int divLeft = lcount / 3;

                int remLeft = lcount % 3;

                int remRight = rcount - divLeft;

                if (remLeft > 0)
                {
                    divRight = remRight / 3;

                    int remFinalRight = remRight % 3;

                    int remFinalLeft = remLeft - divRight;
                }

                totalPair = divLeft + divRight;
            }
            else
            {
                totalPair = 0;
            }
            return totalPair;

        }

        private static int CountPairWhenRCountBig(int lcount, int rcount, int totalPair)
        {
            if (lcount > 0 && rcount > 0)
            {
                int divLeft = 0;
                //This become pair in case remright is 0
                int divRight = rcount / 3;

                int remRight = rcount % 3;

                int remLeft = lcount - divRight;

                if (remRight > 0)
                {
                    divLeft = remLeft / 3;

                    int remFinalLeft = remLeft % 3;

                    int remFinalRight = remRight - divLeft;
                }

                totalPair = divRight + divLeft;
            }
            else
            {
                totalPair = 0;
            }
            return totalPair;
        }

        private static int CountPairWhenRCountBigFromEqual(int lcount, int rcount, int totalPair)
        {
            if (lcount > 0 && rcount > 0)
            {
                int divLeft = 0;
                int remLeft = 0;
                //This become pair in case remright is 0
                int divRight = rcount / 3;

                int remRight = rcount % 3;

                if (lcount >= divRight)
                    remLeft = lcount - divRight;
                else
                    divRight = divRight - lcount;

                if (remRight > 0 && remLeft > 0)
                {
                    divLeft = remLeft / 3;

                    int remFinalLeft = remLeft % 3;

                    int remFinalRight = remRight - divLeft;
                }

                totalPair = divRight + divLeft;
            }
            else
            {
                totalPair = 0;
            }
            return totalPair;
        }

        private static int CountPairWhenLCountBigFromEqual(int lcount, int rcount, int totalPair)
        {
            if (lcount > 0 && rcount > 0)
            {
                int divRight = 0;
                int remRight = 0;
                //This become pair in case remright is 0
                int divLeft = lcount / 3;

                int remLeft = lcount % 3;

                if (rcount >= divLeft)
                    remRight = rcount - divLeft;
                else
                    divLeft = divLeft - rcount;

                if (remLeft > 0 && remRight > 0)
                {
                    divRight = remRight / 3;

                    int remFinalRight = remRight % 3;

                    int remFinalLeft = remLeft - divRight;
                }

                totalPair = divLeft + divRight;
            }
            else
            {
                totalPair = 0;
            }
            return totalPair;
        }
    }
}

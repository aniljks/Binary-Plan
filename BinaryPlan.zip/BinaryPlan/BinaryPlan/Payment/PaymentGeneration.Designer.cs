﻿namespace BinaryPlan.Payment
{
    partial class PaymentGeneration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnUpdatePairAndCount = new System.Windows.Forms.Button();
            this.btnCreatePaymentSession = new System.Windows.Forms.Button();
            this.dtpPaymentStartDate = new System.Windows.Forms.DateTimePicker();
            this.txtPaymentSessionName = new System.Windows.Forms.TextBox();
            this.lblPaySesion = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCheckPairs = new System.Windows.Forms.Button();
            this.PaymentGenerationProgressbar = new System.Windows.Forms.ProgressBar();
            this.btnCheckRegularIncomeLogic = new System.Windows.Forms.Button();
            this.txtLCount = new System.Windows.Forms.TextBox();
            this.txtRCount = new System.Windows.Forms.TextBox();
            this.txtTotalPair = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblStatusPaymentGenration = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnUpdatePairAndCount
            // 
            this.btnUpdatePairAndCount.Location = new System.Drawing.Point(516, 43);
            this.btnUpdatePairAndCount.Name = "btnUpdatePairAndCount";
            this.btnUpdatePairAndCount.Size = new System.Drawing.Size(184, 23);
            this.btnUpdatePairAndCount.TabIndex = 0;
            this.btnUpdatePairAndCount.Text = "Generate Royalty Qualifier (Hard)";
            this.btnUpdatePairAndCount.UseVisualStyleBackColor = true;
            this.btnUpdatePairAndCount.Click += new System.EventHandler(this.btnUpdatePairAndCount_Click);
            // 
            // btnCreatePaymentSession
            // 
            this.btnCreatePaymentSession.Location = new System.Drawing.Point(181, 178);
            this.btnCreatePaymentSession.Name = "btnCreatePaymentSession";
            this.btnCreatePaymentSession.Size = new System.Drawing.Size(200, 23);
            this.btnCreatePaymentSession.TabIndex = 1;
            this.btnCreatePaymentSession.Text = "Create Payment Session";
            this.btnCreatePaymentSession.UseVisualStyleBackColor = true;
            this.btnCreatePaymentSession.Click += new System.EventHandler(this.btnCreatePaymentSession_Click);
            // 
            // dtpPaymentStartDate
            // 
            this.dtpPaymentStartDate.Location = new System.Drawing.Point(181, 87);
            this.dtpPaymentStartDate.Name = "dtpPaymentStartDate";
            this.dtpPaymentStartDate.Size = new System.Drawing.Size(200, 20);
            this.dtpPaymentStartDate.TabIndex = 2;
            // 
            // txtPaymentSessionName
            // 
            this.txtPaymentSessionName.Location = new System.Drawing.Point(181, 46);
            this.txtPaymentSessionName.Name = "txtPaymentSessionName";
            this.txtPaymentSessionName.Size = new System.Drawing.Size(200, 20);
            this.txtPaymentSessionName.TabIndex = 4;
            // 
            // lblPaySesion
            // 
            this.lblPaySesion.AutoSize = true;
            this.lblPaySesion.Location = new System.Drawing.Point(47, 54);
            this.lblPaySesion.Name = "lblPaySesion";
            this.lblPaySesion.Size = new System.Drawing.Size(119, 13);
            this.lblPaySesion.TabIndex = 5;
            this.lblPaySesion.Text = "Payment Session Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(92, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Payment Date";
            // 
            // btnCheckPairs
            // 
            this.btnCheckPairs.Location = new System.Drawing.Point(181, 130);
            this.btnCheckPairs.Name = "btnCheckPairs";
            this.btnCheckPairs.Size = new System.Drawing.Size(200, 23);
            this.btnCheckPairs.TabIndex = 8;
            this.btnCheckPairs.Text = "Generate Regular Income && Royalty ";
            this.btnCheckPairs.UseVisualStyleBackColor = true;
            this.btnCheckPairs.Click += new System.EventHandler(this.btnCheckPairs_Click);
            // 
            // PaymentGenerationProgressbar
            // 
            this.PaymentGenerationProgressbar.Location = new System.Drawing.Point(30, 434);
            this.PaymentGenerationProgressbar.Name = "PaymentGenerationProgressbar";
            this.PaymentGenerationProgressbar.Size = new System.Drawing.Size(810, 23);
            this.PaymentGenerationProgressbar.TabIndex = 14;
            // 
            // btnCheckRegularIncomeLogic
            // 
            this.btnCheckRegularIncomeLogic.Location = new System.Drawing.Point(533, 304);
            this.btnCheckRegularIncomeLogic.Name = "btnCheckRegularIncomeLogic";
            this.btnCheckRegularIncomeLogic.Size = new System.Drawing.Size(212, 23);
            this.btnCheckRegularIncomeLogic.TabIndex = 15;
            this.btnCheckRegularIncomeLogic.Text = "Check Regular income Logic";
            this.btnCheckRegularIncomeLogic.UseVisualStyleBackColor = true;
            this.btnCheckRegularIncomeLogic.Click += new System.EventHandler(this.btnCheckRegularIncomeLogic_Click);
            // 
            // txtLCount
            // 
            this.txtLCount.Location = new System.Drawing.Point(566, 180);
            this.txtLCount.Name = "txtLCount";
            this.txtLCount.Size = new System.Drawing.Size(100, 20);
            this.txtLCount.TabIndex = 16;
            // 
            // txtRCount
            // 
            this.txtRCount.Location = new System.Drawing.Point(566, 219);
            this.txtRCount.Name = "txtRCount";
            this.txtRCount.Size = new System.Drawing.Size(100, 20);
            this.txtRCount.TabIndex = 17;
            // 
            // txtTotalPair
            // 
            this.txtTotalPair.Location = new System.Drawing.Point(566, 261);
            this.txtTotalPair.Name = "txtTotalPair";
            this.txtTotalPair.Size = new System.Drawing.Size(100, 20);
            this.txtTotalPair.TabIndex = 18;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(491, 180);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "Left Count";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(491, 222);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "Right Count";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(491, 268);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 13);
            this.label4.TabIndex = 21;
            this.label4.Text = "Total Pair";
            // 
            // lblStatusPaymentGenration
            // 
            this.lblStatusPaymentGenration.AutoSize = true;
            this.lblStatusPaymentGenration.Location = new System.Drawing.Point(47, 404);
            this.lblStatusPaymentGenration.Name = "lblStatusPaymentGenration";
            this.lblStatusPaymentGenration.Size = new System.Drawing.Size(0, 13);
            this.lblStatusPaymentGenration.TabIndex = 22;
            // 
            // PaymentGeneration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(897, 486);
            this.Controls.Add(this.lblStatusPaymentGenration);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtTotalPair);
            this.Controls.Add(this.txtRCount);
            this.Controls.Add(this.txtLCount);
            this.Controls.Add(this.btnCheckRegularIncomeLogic);
            this.Controls.Add(this.PaymentGenerationProgressbar);
            this.Controls.Add(this.btnCheckPairs);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblPaySesion);
            this.Controls.Add(this.txtPaymentSessionName);
            this.Controls.Add(this.dtpPaymentStartDate);
            this.Controls.Add(this.btnCreatePaymentSession);
            this.Controls.Add(this.btnUpdatePairAndCount);
            this.Name = "PaymentGeneration";
            this.Text = "PaymentGeneration";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUpdatePairAndCount;
        private System.Windows.Forms.Button btnCreatePaymentSession;
        private System.Windows.Forms.DateTimePicker dtpPaymentStartDate;
        private System.Windows.Forms.TextBox txtPaymentSessionName;
        private System.Windows.Forms.Label lblPaySesion;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCheckPairs;
        private System.Windows.Forms.ProgressBar PaymentGenerationProgressbar;
        private System.Windows.Forms.Button btnCheckRegularIncomeLogic;
        private System.Windows.Forms.TextBox txtLCount;
        private System.Windows.Forms.TextBox txtRCount;
        private System.Windows.Forms.TextBox txtTotalPair;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblStatusPaymentGenration;
    }
}
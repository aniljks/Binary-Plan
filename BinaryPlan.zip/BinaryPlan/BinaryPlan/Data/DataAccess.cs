﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using log = BinaryPlan.Common;

namespace BinaryPlan.Data
{
    public class DataAccess : IDisposable
    {



        SqlDataAdapter adpt = new SqlDataAdapter();

        string connectionString = string.Empty;
        public DataAccess()
        {
            connectionString = ConfigurationManager.ConnectionStrings["BPlanCon"].ToString();
        }

        public DataSet FillDataSP(string query, SqlParameter[] sqlParam)
        {
            DataSet ds = new DataSet();
            try
            {

                ds.Tables.Clear();

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    //con.ConnectionString = connectionString;

                    if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                        con.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = con;
                        cmd.CommandTimeout = 0;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = query;
                        cmd.Parameters.Clear();
                        cmd.Parameters.AddRange(sqlParam);
                        //cmd.ExecuteNonQuery();                    
                        adpt.SelectCommand = cmd;
                        adpt.Fill(ds);
                        adpt.Dispose();
                        cmd.Dispose();
                        con.Dispose();
                        con.Close();

                    }
                }
            }
            catch (Exception ex)
            {
                log.Logger.Log(ex.Message, ex.StackTrace);
            }

            return ds;
        }

        public DataSet FillData(string query)
        {
            DataSet ds = new DataSet();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                //con.ConnectionString = connectionString;

                if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                    con.Open();

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = con;
                    cmd.CommandTimeout = 60;
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = query;
                    cmd.ExecuteNonQuery();
                    adpt.SelectCommand = cmd;
                    adpt.Fill(ds);
                    con.Close();
                    return ds;
                }
            }
        }


        public void Dispose()
        {

        }
    }
}

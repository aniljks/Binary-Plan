﻿namespace BinaryPlan.MainForm
{
    partial class RegistrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRegistrationFormHeading = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.tabRegistration = new System.Windows.Forms.TabControl();
            this.TabPersonal = new System.Windows.Forms.TabPage();
            this.lblGender = new System.Windows.Forms.Label();
            this.cmbGender = new System.Windows.Forms.ComboBox();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.lblContact = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.txtParentName = new System.Windows.Forms.TextBox();
            this.lblParentName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.tabPlan = new System.Windows.Forms.TabPage();
            this.grpPlanDetail = new System.Windows.Forms.GroupBox();
            this.lblJoiningAmount = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblPlanName = new System.Windows.Forms.Label();
            this.PlanNamelbl = new System.Windows.Forms.Label();
            this.lblParentAccountName = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbPlan = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.CLD_DOJ = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbSide = new System.Windows.Forms.ComboBox();
            this.txtSponcerId = new System.Windows.Forms.TextBox();
            this.lblSponcer = new System.Windows.Forms.Label();
            this.lblParentAccount = new System.Windows.Forms.Label();
            this.cmbParentAccount = new System.Windows.Forms.ComboBox();
            this.tbBankDetail = new System.Windows.Forms.TabPage();
            this.lblBankName = new System.Windows.Forms.Label();
            this.txtBankName = new System.Windows.Forms.TextBox();
            this.txtAccountNo = new System.Windows.Forms.TextBox();
            this.lblAccountNo = new System.Windows.Forms.Label();
            this.txtIFSCCode = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtAccountHolderName = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtBranchName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tabRegistration.SuspendLayout();
            this.TabPersonal.SuspendLayout();
            this.tabPlan.SuspendLayout();
            this.grpPlanDetail.SuspendLayout();
            this.tbBankDetail.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblRegistrationFormHeading
            // 
            this.lblRegistrationFormHeading.AutoSize = true;
            this.lblRegistrationFormHeading.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegistrationFormHeading.Location = new System.Drawing.Point(307, 19);
            this.lblRegistrationFormHeading.Name = "lblRegistrationFormHeading";
            this.lblRegistrationFormHeading.Size = new System.Drawing.Size(231, 29);
            this.lblRegistrationFormHeading.TabIndex = 18;
            this.lblRegistrationFormHeading.Text = "Registration Form";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(153, 473);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 19;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(251, 473);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 20;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // tabRegistration
            // 
            this.tabRegistration.Controls.Add(this.TabPersonal);
            this.tabRegistration.Controls.Add(this.tabPlan);
            this.tabRegistration.Controls.Add(this.tbBankDetail);
            this.tabRegistration.Location = new System.Drawing.Point(32, 66);
            this.tabRegistration.Name = "tabRegistration";
            this.tabRegistration.SelectedIndex = 0;
            this.tabRegistration.Size = new System.Drawing.Size(829, 384);
            this.tabRegistration.TabIndex = 25;
            // 
            // TabPersonal
            // 
            this.TabPersonal.Controls.Add(this.lblGender);
            this.TabPersonal.Controls.Add(this.cmbGender);
            this.TabPersonal.Controls.Add(this.txtContact);
            this.TabPersonal.Controls.Add(this.lblContact);
            this.TabPersonal.Controls.Add(this.txtAddress);
            this.TabPersonal.Controls.Add(this.lblAddress);
            this.TabPersonal.Controls.Add(this.txtParentName);
            this.TabPersonal.Controls.Add(this.lblParentName);
            this.TabPersonal.Controls.Add(this.txtName);
            this.TabPersonal.Controls.Add(this.lblName);
            this.TabPersonal.Location = new System.Drawing.Point(4, 22);
            this.TabPersonal.Name = "TabPersonal";
            this.TabPersonal.Padding = new System.Windows.Forms.Padding(3);
            this.TabPersonal.Size = new System.Drawing.Size(821, 358);
            this.TabPersonal.TabIndex = 0;
            this.TabPersonal.Text = "Personal";
            this.TabPersonal.UseVisualStyleBackColor = true;
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Location = new System.Drawing.Point(58, 223);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(42, 13);
            this.lblGender.TabIndex = 44;
            this.lblGender.Text = "Gender";
            // 
            // cmbGender
            // 
            this.cmbGender.FormattingEnabled = true;
            this.cmbGender.Items.AddRange(new object[] {
            "--Select Gender--",
            "Male",
            "Female"});
            this.cmbGender.Location = new System.Drawing.Point(120, 220);
            this.cmbGender.Name = "cmbGender";
            this.cmbGender.Size = new System.Drawing.Size(121, 21);
            this.cmbGender.TabIndex = 43;
            // 
            // txtContact
            // 
            this.txtContact.Location = new System.Drawing.Point(120, 186);
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(254, 20);
            this.txtContact.TabIndex = 32;
            // 
            // lblContact
            // 
            this.lblContact.AutoSize = true;
            this.lblContact.Location = new System.Drawing.Point(60, 189);
            this.lblContact.Name = "lblContact";
            this.lblContact.Size = new System.Drawing.Size(44, 13);
            this.lblContact.TabIndex = 31;
            this.lblContact.Text = "Contact";
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(120, 89);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(254, 82);
            this.txtAddress.TabIndex = 30;
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(59, 92);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(45, 13);
            this.lblAddress.TabIndex = 29;
            this.lblAddress.Text = "Address";
            // 
            // txtParentName
            // 
            this.txtParentName.Location = new System.Drawing.Point(120, 50);
            this.txtParentName.Name = "txtParentName";
            this.txtParentName.Size = new System.Drawing.Size(254, 20);
            this.txtParentName.TabIndex = 28;
            // 
            // lblParentName
            // 
            this.lblParentName.AutoSize = true;
            this.lblParentName.Location = new System.Drawing.Point(35, 53);
            this.lblParentName.Name = "lblParentName";
            this.lblParentName.Size = new System.Drawing.Size(69, 13);
            this.lblParentName.TabIndex = 27;
            this.lblParentName.Text = "Parent Name";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(120, 10);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(254, 20);
            this.txtName.TabIndex = 26;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(73, 13);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(35, 13);
            this.lblName.TabIndex = 25;
            this.lblName.Text = "Name";
            // 
            // tabPlan
            // 
            this.tabPlan.Controls.Add(this.grpPlanDetail);
            this.tabPlan.Controls.Add(this.lblParentAccountName);
            this.tabPlan.Controls.Add(this.label4);
            this.tabPlan.Controls.Add(this.cmbPlan);
            this.tabPlan.Controls.Add(this.label3);
            this.tabPlan.Controls.Add(this.CLD_DOJ);
            this.tabPlan.Controls.Add(this.label2);
            this.tabPlan.Controls.Add(this.label1);
            this.tabPlan.Controls.Add(this.cmbSide);
            this.tabPlan.Controls.Add(this.txtSponcerId);
            this.tabPlan.Controls.Add(this.lblSponcer);
            this.tabPlan.Controls.Add(this.lblParentAccount);
            this.tabPlan.Controls.Add(this.cmbParentAccount);
            this.tabPlan.Location = new System.Drawing.Point(4, 22);
            this.tabPlan.Name = "tabPlan";
            this.tabPlan.Padding = new System.Windows.Forms.Padding(3);
            this.tabPlan.Size = new System.Drawing.Size(821, 358);
            this.tabPlan.TabIndex = 1;
            this.tabPlan.Text = "Plan";
            this.tabPlan.UseVisualStyleBackColor = true;
            // 
            // grpPlanDetail
            // 
            this.grpPlanDetail.Controls.Add(this.lblJoiningAmount);
            this.grpPlanDetail.Controls.Add(this.label6);
            this.grpPlanDetail.Controls.Add(this.lblPlanName);
            this.grpPlanDetail.Controls.Add(this.PlanNamelbl);
            this.grpPlanDetail.Location = new System.Drawing.Point(468, 23);
            this.grpPlanDetail.Name = "grpPlanDetail";
            this.grpPlanDetail.Size = new System.Drawing.Size(309, 128);
            this.grpPlanDetail.TabIndex = 59;
            this.grpPlanDetail.TabStop = false;
            this.grpPlanDetail.Text = "Plan Details";
            // 
            // lblJoiningAmount
            // 
            this.lblJoiningAmount.AutoSize = true;
            this.lblJoiningAmount.Location = new System.Drawing.Point(104, 58);
            this.lblJoiningAmount.Name = "lblJoiningAmount";
            this.lblJoiningAmount.Size = new System.Drawing.Size(13, 13);
            this.lblJoiningAmount.TabIndex = 3;
            this.lblJoiningAmount.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 58);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Joining Amount";
            // 
            // lblPlanName
            // 
            this.lblPlanName.AutoSize = true;
            this.lblPlanName.Location = new System.Drawing.Point(104, 29);
            this.lblPlanName.Name = "lblPlanName";
            this.lblPlanName.Size = new System.Drawing.Size(59, 13);
            this.lblPlanName.TabIndex = 1;
            this.lblPlanName.Text = "Plan Name";
            // 
            // PlanNamelbl
            // 
            this.PlanNamelbl.AutoSize = true;
            this.PlanNamelbl.Location = new System.Drawing.Point(19, 29);
            this.PlanNamelbl.Name = "PlanNamelbl";
            this.PlanNamelbl.Size = new System.Drawing.Size(59, 13);
            this.PlanNamelbl.TabIndex = 0;
            this.PlanNamelbl.Text = "Plan Name";
            // 
            // lblParentAccountName
            // 
            this.lblParentAccountName.AutoSize = true;
            this.lblParentAccountName.Location = new System.Drawing.Point(161, 118);
            this.lblParentAccountName.Name = "lblParentAccountName";
            this.lblParentAccountName.Size = new System.Drawing.Size(35, 13);
            this.lblParentAccountName.TabIndex = 58;
            this.lblParentAccountName.Text = "Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(43, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 13);
            this.label4.TabIndex = 57;
            this.label4.Text = "Parent Account Name";
            // 
            // cmbPlan
            // 
            this.cmbPlan.FormattingEnabled = true;
            this.cmbPlan.Items.AddRange(new object[] {
            "0",
            "1"});
            this.cmbPlan.Location = new System.Drawing.Point(161, 34);
            this.cmbPlan.Name = "cmbPlan";
            this.cmbPlan.Size = new System.Drawing.Size(254, 21);
            this.cmbPlan.TabIndex = 56;
            this.cmbPlan.SelectedIndexChanged += new System.EventHandler(this.cmbPlan_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(108, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(28, 13);
            this.label3.TabIndex = 55;
            this.label3.Text = "Plan";
            // 
            // CLD_DOJ
            // 
            this.CLD_DOJ.Location = new System.Drawing.Point(161, 239);
            this.CLD_DOJ.Name = "CLD_DOJ";
            this.CLD_DOJ.Size = new System.Drawing.Size(200, 20);
            this.CLD_DOJ.TabIndex = 54;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(75, 243);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 13);
            this.label2.TabIndex = 53;
            this.label2.Text = "Date Of Joining";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(99, 185);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 52;
            this.label1.Text = "Join Side";
            // 
            // cmbSide
            // 
            this.cmbSide.FormattingEnabled = true;
            this.cmbSide.Items.AddRange(new object[] {
            "--Select Side--",
            "Left",
            "Right"});
            this.cmbSide.Location = new System.Drawing.Point(161, 182);
            this.cmbSide.Name = "cmbSide";
            this.cmbSide.Size = new System.Drawing.Size(121, 21);
            this.cmbSide.TabIndex = 51;
            // 
            // txtSponcerId
            // 
            this.txtSponcerId.Location = new System.Drawing.Point(161, 148);
            this.txtSponcerId.Name = "txtSponcerId";
            this.txtSponcerId.Size = new System.Drawing.Size(254, 20);
            this.txtSponcerId.TabIndex = 50;
            // 
            // lblSponcer
            // 
            this.lblSponcer.AutoSize = true;
            this.lblSponcer.Location = new System.Drawing.Point(90, 151);
            this.lblSponcer.Name = "lblSponcer";
            this.lblSponcer.Size = new System.Drawing.Size(59, 13);
            this.lblSponcer.TabIndex = 49;
            this.lblSponcer.Text = "Sponcer Id";
            // 
            // lblParentAccount
            // 
            this.lblParentAccount.AutoSize = true;
            this.lblParentAccount.Location = new System.Drawing.Point(62, 82);
            this.lblParentAccount.Name = "lblParentAccount";
            this.lblParentAccount.Size = new System.Drawing.Size(93, 13);
            this.lblParentAccount.TabIndex = 48;
            this.lblParentAccount.Text = "Parent Account Id";
            // 
            // cmbParentAccount
            // 
            this.cmbParentAccount.FormattingEnabled = true;
            this.cmbParentAccount.Items.AddRange(new object[] {
            "0",
            "1"});
            this.cmbParentAccount.Location = new System.Drawing.Point(161, 78);
            this.cmbParentAccount.Name = "cmbParentAccount";
            this.cmbParentAccount.Size = new System.Drawing.Size(254, 21);
            this.cmbParentAccount.TabIndex = 47;
            this.cmbParentAccount.SelectedIndexChanged += new System.EventHandler(this.cmbParentAccount_SelectedIndexChanged);
            // 
            // tbBankDetail
            // 
            this.tbBankDetail.Controls.Add(this.txtBranchName);
            this.tbBankDetail.Controls.Add(this.label5);
            this.tbBankDetail.Controls.Add(this.txtAccountHolderName);
            this.tbBankDetail.Controls.Add(this.label8);
            this.tbBankDetail.Controls.Add(this.txtIFSCCode);
            this.tbBankDetail.Controls.Add(this.label7);
            this.tbBankDetail.Controls.Add(this.txtAccountNo);
            this.tbBankDetail.Controls.Add(this.lblAccountNo);
            this.tbBankDetail.Controls.Add(this.txtBankName);
            this.tbBankDetail.Controls.Add(this.lblBankName);
            this.tbBankDetail.Location = new System.Drawing.Point(4, 22);
            this.tbBankDetail.Name = "tbBankDetail";
            this.tbBankDetail.Padding = new System.Windows.Forms.Padding(3);
            this.tbBankDetail.Size = new System.Drawing.Size(821, 358);
            this.tbBankDetail.TabIndex = 2;
            this.tbBankDetail.Text = "Bank Detail";
            this.tbBankDetail.UseVisualStyleBackColor = true;
            // 
            // lblBankName
            // 
            this.lblBankName.AutoSize = true;
            this.lblBankName.Location = new System.Drawing.Point(105, 103);
            this.lblBankName.Name = "lblBankName";
            this.lblBankName.Size = new System.Drawing.Size(63, 13);
            this.lblBankName.TabIndex = 0;
            this.lblBankName.Text = "Bank Name";
            // 
            // txtBankName
            // 
            this.txtBankName.Location = new System.Drawing.Point(184, 103);
            this.txtBankName.Name = "txtBankName";
            this.txtBankName.Size = new System.Drawing.Size(244, 20);
            this.txtBankName.TabIndex = 1;
            // 
            // txtAccountNo
            // 
            this.txtAccountNo.Location = new System.Drawing.Point(184, 146);
            this.txtAccountNo.Name = "txtAccountNo";
            this.txtAccountNo.Size = new System.Drawing.Size(244, 20);
            this.txtAccountNo.TabIndex = 3;
            // 
            // lblAccountNo
            // 
            this.lblAccountNo.AutoSize = true;
            this.lblAccountNo.Location = new System.Drawing.Point(105, 146);
            this.lblAccountNo.Name = "lblAccountNo";
            this.lblAccountNo.Size = new System.Drawing.Size(64, 13);
            this.lblAccountNo.TabIndex = 2;
            this.lblAccountNo.Text = "Account No";
            // 
            // txtIFSCCode
            // 
            this.txtIFSCCode.Location = new System.Drawing.Point(184, 189);
            this.txtIFSCCode.Name = "txtIFSCCode";
            this.txtIFSCCode.Size = new System.Drawing.Size(244, 20);
            this.txtIFSCCode.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(105, 189);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "IFSC Code";
            // 
            // txtAccountHolderName
            // 
            this.txtAccountHolderName.Location = new System.Drawing.Point(184, 68);
            this.txtAccountHolderName.Name = "txtAccountHolderName";
            this.txtAccountHolderName.Size = new System.Drawing.Size(244, 20);
            this.txtAccountHolderName.TabIndex = 7;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(56, 68);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(112, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Account Holder Name";
            // 
            // txtBranchName
            // 
            this.txtBranchName.Location = new System.Drawing.Point(184, 229);
            this.txtBranchName.Name = "txtBranchName";
            this.txtBranchName.Size = new System.Drawing.Size(244, 20);
            this.txtBranchName.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(105, 229);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Bank Branch";
            // 
            // RegistrationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(892, 620);
            this.Controls.Add(this.tabRegistration);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lblRegistrationFormHeading);
            this.Name = "RegistrationForm";
            this.Text = "Registration Form";
            this.tabRegistration.ResumeLayout(false);
            this.TabPersonal.ResumeLayout(false);
            this.TabPersonal.PerformLayout();
            this.tabPlan.ResumeLayout(false);
            this.tabPlan.PerformLayout();
            this.grpPlanDetail.ResumeLayout(false);
            this.grpPlanDetail.PerformLayout();
            this.tbBankDetail.ResumeLayout(false);
            this.tbBankDetail.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblRegistrationFormHeading;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.TabControl tabRegistration;
        private System.Windows.Forms.TabPage TabPersonal;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.ComboBox cmbGender;
        private System.Windows.Forms.TextBox txtContact;
        private System.Windows.Forms.Label lblContact;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.TextBox txtParentName;
        private System.Windows.Forms.Label lblParentName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TabPage tabPlan;
        private System.Windows.Forms.Label lblParentAccountName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbPlan;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker CLD_DOJ;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbSide;
        private System.Windows.Forms.TextBox txtSponcerId;
        private System.Windows.Forms.Label lblSponcer;
        private System.Windows.Forms.Label lblParentAccount;
        private System.Windows.Forms.ComboBox cmbParentAccount;
        private System.Windows.Forms.GroupBox grpPlanDetail;
        private System.Windows.Forms.Label PlanNamelbl;
        private System.Windows.Forms.Label lblJoiningAmount;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblPlanName;
        private System.Windows.Forms.TabPage tbBankDetail;
        private System.Windows.Forms.TextBox txtBranchName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtAccountHolderName;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtIFSCCode;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtAccountNo;
        private System.Windows.Forms.Label lblAccountNo;
        private System.Windows.Forms.TextBox txtBankName;
        private System.Windows.Forms.Label lblBankName;
    }
}


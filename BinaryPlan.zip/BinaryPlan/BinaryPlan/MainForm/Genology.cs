﻿using BinaryPlan.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using log = BinaryPlan.Common;
using System.Configuration;

namespace BinaryPlan.MainForm
{
    public partial class Genology : Form
    {
        static string baseAccountId = string.Empty;
        static Genology()
        {
            baseAccountId = ConfigurationManager.AppSettings["BaseAccountId"].ToString();
        }
        public Genology()
        {
            InitializeComponent();
            int baseAccId = Convert.ToInt16(baseAccountId);
            FillTree(baseAccId);
        }

        public void FillTree(int accountId)
        {
            try
            {
                treeViewBinary.Nodes.Clear();
                using (BPlanEntities ctx = new BPlanEntities())
                {
                    var firstParent = ctx.Account_Details.Where(x => x.Acc_Id == accountId).FirstOrDefault();

                    if (firstParent != null)
                    {
                        TreeNode tn = new TreeNode(firstParent.Acc_Id.ToString());
                        tn.ToolTipText = "Advisor Account Id:" + firstParent.Acc_Id + Environment.NewLine +
                                "Advisor Name : " + firstParent.Account_Master.Acc_Name + " " + Environment.NewLine +
                                "Date of Joining : " + firstParent.DOJ + " " + Environment.NewLine +
                                "Sponcer : " + firstParent.Sponcer_Id + " " + Environment.NewLine;
                        tn.Nodes.Add(new TreeNode());
                        treeViewBinary.Nodes.Add(tn);
                    }
                    else
                    {
                        ShowValidationMessage("AccountId does not exist! " + Environment.NewLine + " Please try with a valid accountId!");
                    }
                }

                treeViewBinary.BeforeExpand += treeViewBinary_BeforeExpand;
            }
            catch (Exception ex)
            {
                log.Logger.Log(ex.Message, ex.StackTrace);
                MessageBox.Show("There is some issue in displaying the Tree. Please try again to open the tree! Thanks!");
            }

        }

        private void treeViewBinary_BeforeExpand(object sender, TreeViewCancelEventArgs e)
        {
            TreeNode tNode = e.Node;
            string accId = tNode.Text;
            int acc_Id = 0;
            if (int.TryParse(accId, out acc_Id))
            {
                tNode.Nodes.Clear();
                using (BPlanEntities ctx = new BPlanEntities())
                {
                    var firstChilds = ctx.Account_Details.Where(x => x.Parent_Id == acc_Id).ToList();

                    if (firstChilds != null)
                    {
                        TreeNode LeftChild = null;
                        TreeNode RightChild = null;
                        foreach (var childAccId in firstChilds)
                        {

                            if (childAccId.Side.ToUpper().Trim() == "LEFT")
                            {
                                LeftChild = new TreeNode(childAccId.Acc_Id.ToString());
                                LeftChild.ToolTipText = "Advisor Account Id:" + childAccId.Acc_Id + Environment.NewLine +
                                "Advisor Name : " + childAccId.Account_Master.Acc_Name + " " + Environment.NewLine +
                                "Date of Joining : " + childAccId.DOJ + " " + Environment.NewLine +
                                "Sponcer : " + childAccId.Sponcer_Id + " " + Environment.NewLine;
                                LeftChild.Nodes.Add(new TreeNode());
                            }

                            if (childAccId.Side.ToUpper().Trim() == "RIGHT")
                            {
                                RightChild = new TreeNode(childAccId.Acc_Id.ToString());
                                RightChild.ToolTipText = "Advisor Account Id:" + childAccId.Acc_Id + Environment.NewLine +
                                "Advisor Name : " + childAccId.Account_Master.Acc_Name + " " + Environment.NewLine +
                                "Date of Joining : " + childAccId.DOJ + " " + Environment.NewLine+
                                "Sponcer : " + childAccId.Sponcer_Id + " " + Environment.NewLine;
                                RightChild.Nodes.Add(new TreeNode());
                            }
                        }

                        if (LeftChild == null)
                        {
                            LeftChild = new TreeNode("This parent has No LEFT Child");

                        }
                        if (RightChild == null)
                        {
                            RightChild = new TreeNode("This parent has No RIGHT Child");
                        }

                        tNode.Nodes.AddRange(new TreeNode[] { LeftChild, RightChild });

                    }
                }
            }

        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtAccountId.Text))
                {
                    int accId = 0;
                    int baseAccId = 0;
                    if (int.TryParse(txtAccountId.Text, out accId))
                    {


                        baseAccId = Convert.ToInt16(baseAccountId);

                        if (accId != 0)
                        {
                            FillTree(accId);
                        }
                        else
                        {
                            FillTree(baseAccId);
                        }

                    }

                }
            }
            catch (Exception ex)
            {
                log.Logger.Log(ex.Message, ex.StackTrace);
            }

        }

        private void ShowValidationMessage(string Message)
        {
            MessageBox.Show(Message);
        }
    }

}

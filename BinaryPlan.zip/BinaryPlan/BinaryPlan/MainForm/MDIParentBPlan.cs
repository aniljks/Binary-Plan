﻿using BinaryPlan.Payment;
using BinaryPlan.Report;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BinaryPlan.MainForm
{
    public partial class MDIParentBPlan : Form
    {
        private int childFormNumber = 0;

        public MDIParentBPlan()
        {
            InitializeComponent();
        }

        private void ShowNewForm(object sender, EventArgs e)
        {
            Form childForm = new Form();
            childForm.MdiParent = this;
            childForm.Text = "Window " + childFormNumber++;
            childForm.Show();
        }

        private void OpenFile(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = openFileDialog.FileName;
            }
        }

        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = saveFileDialog.FileName;
            }
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CutToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void CopyToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void PasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }





        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void registrationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RegistrationForm regForm = new RegistrationForm();
            regForm.MdiParent = this;
            regForm.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void genologyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Genology genology = new Genology();
            genology.MdiParent = this;
            genology.Show();

        }

        private void advisorDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FindAdvisorDetail findAdvisorDetail = new FindAdvisorDetail();
            findAdvisorDetail.MdiParent = this;
            findAdvisorDetail.Show();
        }

        private void paymentGenerationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PaymentGeneration payGeneration = new PaymentGeneration();
            payGeneration.MdiParent = this;
            payGeneration.Show();
        }

        private void pairDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FindPairDetails findPairDetails = new FindPairDetails();
            findPairDetails.MdiParent = this;
            findPairDetails.Show();
        }

        private void settingToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Settings setting = new Settings();
            setting.MdiParent = this;
            setting.Show();
        }

        private void incomeDetailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AccountIncome accountIncome = new AccountIncome();
            accountIncome.MdiParent = this;
            accountIncome.Show();
        }
    }
}

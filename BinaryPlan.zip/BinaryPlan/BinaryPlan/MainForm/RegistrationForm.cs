﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BinaryPlan.Data;
using log = BinaryPlan.Common;

namespace BinaryPlan.MainForm
{
    public partial class RegistrationForm : Form
    {
        List<string> lstValidationMessage;
        public RegistrationForm()
        {
            InitializeComponent();
            FillAllCombo();
            lstValidationMessage = new List<string>();
        }

        private void FillAllCombo()
        {
            FillComboParentId();
            FillComboPlan();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            #region Validation
            //Vlidate all drop down should selected
            bool isValid = true;
            if (!(cmbGender.SelectedIndex > 0))
            {
                lstValidationMessage.Add("Select Gender!");
                isValid = false;
            }
            if (!(cmbParentAccount.SelectedIndex > 0))
            {
                lstValidationMessage.Add("Select Parent Account Id!");
                isValid = false;
            }
            if (!(cmbPlan.SelectedIndex > 0))
            {
                lstValidationMessage.Add("Select Plan!");
                isValid = false;
            }
            if (!(cmbSide.SelectedIndex > 0))
            {
                lstValidationMessage.Add("Select Side!");
                isValid = false;
            }
            if (string.IsNullOrEmpty(txtSponcerId.Text))
            {
                lstValidationMessage.Add("Enter Sponcer Id!");
                isValid = false;
            }
            if (string.IsNullOrEmpty(txtAccountHolderName.Text))
            {
                lstValidationMessage.Add("Bank Detail: Enter Account Holder Name!");
                isValid = false;
            }
            if (string.IsNullOrEmpty(txtAccountNo.Text))
            {
                lstValidationMessage.Add("Bank Detail: Enter Account No");
                isValid = false;
            }

            if (!isValid)
            {
                ShowValidationMessage(lstValidationMessage);
                return;
            }

            #endregion
            bool isPairCompleted = false;
            Guid txnId = Guid.NewGuid();
            using (BPlanEntities ctx = new BPlanEntities())
            {
                using (System.Data.Entity.DbContextTransaction dbTran = ctx.Database.BeginTransaction())
                {
                    try
                    {


                        //Check side which it adding should be availble to add for parent
                        int parentId = Convert.ToInt16(cmbParentAccount.Text);
                        string JoiningSide = cmbSide.Text;
                        var accountSideCheck = ctx.Account_Details.Where(x => x.Parent_Id == parentId && x.Side.ToLower().Trim() == JoiningSide.ToLower().Trim()).FirstOrDefault();
                        if (accountSideCheck == null)
                        {
                            #region Account Master
                            Account_Master account_Master = new Account_Master();
                            account_Master.Acc_Address = txtAddress.Text;
                            account_Master.Acc_Name = txtName.Text;
                            account_Master.Gender = cmbGender.Text.ToString();
                            account_Master.ParentName = txtParentName.Text;
                            account_Master.TxnId = txnId.ToString().ToUpper();
                            #endregion

                            #region Account Detail
                            Account_Details account_Details = new Account_Details();
                            account_Details.DOJ = CLD_DOJ.Value;
                            account_Details.Parent_Id = parentId;
                            account_Details.Side = JoiningSide;
                            account_Details.Right_Id = 0;
                            account_Details.Left_Id = 0;
                            account_Details.L_Count = 0;
                            account_Details.L_Count = 0;
                            account_Details.Old_Pair = 0;
                            account_Details.Pair = 0;
                            account_Details.TreeLevel = 0;


                            account_Details.TxnId = txnId.ToString().ToUpper();
                            //Plan
                            account_Details.PlanId = Convert.ToInt32(cmbPlan.SelectedValue);

                            int sponcerId = Convert.ToInt32(txtSponcerId.Text);

                            if (ctx.Account_Master.Where(x => x.Acc_Id == sponcerId).FirstOrDefault() != null)
                            {

                                //TODO: Check sponcer should be parent only in the same side
                                var sponcerDetail = ctx.Account_Details.Where(x => x.Acc_Id == sponcerId).FirstOrDefault();
                                if (sponcerDetail != null)
                                {
                                    int SponcerParentId = sponcerDetail.Parent_Id.HasValue ? sponcerDetail.Parent_Id.Value : 0;
                                    while (SponcerParentId != 0)
                                    {
                                        SponcerParentId = 0;

                                    }

                                    account_Details.Sponcer_Id = Convert.ToInt32(txtSponcerId.Text);
                                }
                                else
                                {
                                    ShowValidationMessage("Sponcer should be from same leg!");
                                    return;
                                }
                            }
                            else
                            {
                                ShowValidationMessage("Enter a valid Sponcer Id!");
                                return;
                            }

                            #endregion

                            #region Bank Detail
                            BankDetail bankDetail = new Data.BankDetail();
                            bankDetail.AccountHolderName = txtAccountHolderName.Text;
                            bankDetail.BankAccountNo = txtAccountNo.Text;
                            bankDetail.BankBranch = txtBranchName.Text;
                            bankDetail.BankName = txtBankName.Text;
                            bankDetail.IFSCCode = txtIFSCCode.Text;

                            #endregion

                            #region one Time Payment Detail on joining

                            //Update Pair Count for Parent Id and also left and right count 

                            using (BPlanEntities updateCtx = new BPlanEntities())
                            {
                                var ParentAccount = updateCtx.Account_Details.Where(x => x.Acc_Id == parentId).FirstOrDefault();
                                //ParentAccount.TreeLevel = ParentAccount.TreeLevel + 1;
                                if (JoiningSide.ToUpper().Trim() == "LEFT")
                                {
                                    ParentAccount.L_Count = ParentAccount.L_Count + 1;
                                }
                                else
                                {
                                    ParentAccount.R_Count = ParentAccount.R_Count + 1;
                                }

                                int parentToUpdate = ParentAccount.Parent_Id.Value;
                                while (parentToUpdate != 0)
                                {
                                    var parentToUpdateObj = updateCtx.Account_Details.Where(x => x.Acc_Id == parentToUpdate).FirstOrDefault();
                                    var parentsParentToUpdateObj = updateCtx.Account_Details.Where(x => x.Acc_Id == parentToUpdateObj.Parent_Id).FirstOrDefault();
                                    if (parentToUpdateObj != null && parentsParentToUpdateObj != null)
                                    {

                                        if (ParentAccount.Side.ToLower().Trim() == "left")
                                        {
                                            parentToUpdateObj.L_Count = parentToUpdateObj.L_Count + 1;
                                        }
                                        else
                                        {
                                            parentToUpdateObj.R_Count = parentToUpdateObj.R_Count + 1;
                                        }


                                        if (parentToUpdateObj.Side.ToLower().Trim() == "left")
                                        {
                                            parentsParentToUpdateObj.L_Count = parentsParentToUpdateObj.L_Count + 1;
                                        }
                                        else
                                        {
                                            parentsParentToUpdateObj.R_Count = parentsParentToUpdateObj.R_Count + 1;
                                        }
                                        parentToUpdate = parentsParentToUpdateObj.Parent_Id.Value;
                                        updateCtx.Entry(parentToUpdateObj).State = System.Data.Entity.EntityState.Modified;
                                        updateCtx.Entry(parentsParentToUpdateObj).State = System.Data.Entity.EntityState.Modified;
                                        updateCtx.SaveChanges();
                                    }
                                    else if (parentToUpdateObj != null && parentsParentToUpdateObj == null)
                                    {
                                        if (ParentAccount.Side.ToLower().Trim() == "left")
                                        {
                                            parentToUpdateObj.L_Count = parentToUpdateObj.L_Count + 1;
                                        }
                                        else
                                        {
                                            parentToUpdateObj.R_Count = parentToUpdateObj.R_Count + 1;
                                        }
                                        parentToUpdate = parentToUpdateObj.Parent_Id.Value;

                                        updateCtx.Entry(parentToUpdateObj).State = System.Data.Entity.EntityState.Modified;
                                        updateCtx.SaveChanges();
                                    }

                                }


                                //Pair Sale incentive : 500 only when first pair completed by parent
                                PaymentDetail pairSaleIncentivePaymentDetail = new Data.PaymentDetail();

                                var accountPairComplete = ctx.Account_Details.Where(x => x.Parent_Id == parentId && x.Side != JoiningSide).FirstOrDefault();
                                if (accountPairComplete != null)
                                {
                                    isPairCompleted = true;
                                    //Update pair count by 1 
                                    ParentAccount.Pair = ParentAccount.Pair + 1;

                                    var pairSaleIncentive = ctx.Income_Type.Where(x => x.IncomeId == 2 && x.IncomeFreequency == "1").FirstOrDefault();
                                    if (pairSaleIncentive != null)
                                    {
                                        pairSaleIncentivePaymentDetail.Acc_Id = parentId;
                                        pairSaleIncentivePaymentDetail.Amount = pairSaleIncentive.BasicAmount;
                                        pairSaleIncentivePaymentDetail.IncomeTypeId = pairSaleIncentive.IncomeId;
                                        //pairSaleIncentivePaymentDetail.JoinerId = account_Master.Acc_Id;
                                        pairSaleIncentivePaymentDetail.PaymentDate = DateTime.Now;
                                        pairSaleIncentivePaymentDetail.TxnId = txnId.ToString().ToUpper();
                                        ctx.PaymentDetails.Add(pairSaleIncentivePaymentDetail);
                                    }
                                }

                                updateCtx.Entry(ParentAccount).State = System.Data.Entity.EntityState.Modified;
                                updateCtx.SaveChanges();
                            }


                            //Spill Incentive : one time 300 to the parent for which the sponcer will get direct incentive of 1000 who is adding the ID

                            if (account_Details.Sponcer_Id != account_Details.Parent_Id)
                            {
                                //Spill 300 goes to parent of the joiner 
                                PaymentDetail spillIncentivePaymentDetail = new Data.PaymentDetail();
                                var spillIncentive = ctx.Income_Type.Where(x => x.IncomeId == 3 && x.IncomeFreequency == "1").FirstOrDefault();
                                if (spillIncentive != null)
                                {
                                    spillIncentivePaymentDetail.Acc_Id = parentId;
                                    spillIncentivePaymentDetail.Amount = spillIncentive.BasicAmount;
                                    spillIncentivePaymentDetail.IncomeTypeId = spillIncentive.IncomeId;
                                    spillIncentivePaymentDetail.PaymentDate = DateTime.Now;
                                    spillIncentivePaymentDetail.TxnId = txnId.ToString().ToUpper();
                                    ctx.PaymentDetails.Add(spillIncentivePaymentDetail);
                                }

                                //Direct Incentive 1000 goes to sponcer 
                                PaymentDetail directIncentivePaymentDetail = new Data.PaymentDetail();
                                var directIncentive = ctx.Income_Type.Where(x => x.IncomeId == 1 && x.IncomeFreequency == "1").FirstOrDefault();
                                if (directIncentive != null)
                                {
                                    directIncentivePaymentDetail.Acc_Id = account_Details.Sponcer_Id != 0 ? account_Details.Sponcer_Id : 0;
                                    directIncentivePaymentDetail.Amount = directIncentive.BasicAmount;
                                    directIncentivePaymentDetail.IncomeTypeId = spillIncentive.IncomeId;
                                    //directIncentivePaymentDetail.JoinerId = account_Master.Acc_Id;
                                    directIncentivePaymentDetail.PaymentDate = DateTime.Now;
                                    directIncentivePaymentDetail.TxnId = txnId.ToString().ToUpper();
                                    ctx.PaymentDetails.Add(directIncentivePaymentDetail);
                                }
                            }
                            else
                            {
                                //Direct Incentive 1000 
                                PaymentDetail directIncentivePaymentDetail = new Data.PaymentDetail();
                                var directIncentive = ctx.Income_Type.Where(x => x.IncomeId == 1 && x.IncomeFreequency == "1").FirstOrDefault();
                                if (directIncentive != null)
                                {
                                    directIncentivePaymentDetail.Acc_Id = parentId;
                                    directIncentivePaymentDetail.Amount = directIncentive.BasicAmount;
                                    directIncentivePaymentDetail.IncomeTypeId = directIncentive.IncomeId;
                                    //directIncentivePaymentDetail.JoinerId = account_Master.Acc_Id;
                                    directIncentivePaymentDetail.PaymentDate = DateTime.Now;
                                    directIncentivePaymentDetail.TxnId = txnId.ToString().ToUpper();
                                    ctx.PaymentDetails.Add(directIncentivePaymentDetail);
                                }

                                //No Spill incentive in this case
                            }
                            #endregion

                            #region Save all account related data through context
                            ctx.Account_Master.Add(account_Master);
                            account_Master.Account_Details.Add(account_Details);
                            account_Master.BankDetails.Add(bankDetail);
                            ctx.SaveChanges();
                            int LatestAccId = account_Master.Acc_Id;
                            dbTran.Commit();

                            #region Level update code not required
                            //Update Level of Joiner's all parent
                            //int ParentAccountId = parentId;
                            //do
                            //{
                            //    if (!isPairCompleted)
                            //    {
                            //        using (BPlanEntities updateLevelContext = new BPlanEntities())
                            //        {
                            //            var parentToUpdate = updateLevelContext.Account_Details.Where(x => x.Acc_Id == ParentAccountId).FirstOrDefault();
                            //            if (parentToUpdate != null)
                            //            {
                            //                ParentAccountId = Convert.ToInt16(parentToUpdate.Parent_Id);
                            //                parentToUpdate.TreeLevel = parentToUpdate.TreeLevel + 1;
                            //            }
                            //            else
                            //            {
                            //                ParentAccountId = 0;
                            //            }
                            //            updateLevelContext.SaveChanges();
                            //        }
                            //    }
                            //    else
                            //    {
                            //        ParentAccountId = 0;
                            //    }
                            //}
                            //while (ParentAccountId != 0);
                            #endregion

                            using (BPlanEntities cotx = new BPlanEntities())
                            {

                                var accountDetail = cotx.Account_Details.Where(x => x.Acc_Id == LatestAccId).FirstOrDefault();

                                var parentAccount = cotx.Account_Details.Where(x => x.Acc_Id == accountDetail.Parent_Id).FirstOrDefault();
                                if (JoiningSide.ToUpper().Trim() == "LEFT")
                                    parentAccount.Left_Id = LatestAccId;
                                else
                                    parentAccount.Right_Id = LatestAccId;

                                cotx.Entry(parentAccount).State = System.Data.Entity.EntityState.Modified;
                                cotx.SaveChanges();

                            }

                            MessageBox.Show("Registration Successful!");
                            log.Logger.Log("txnId " + txnId + "Succesfully commited! ", String.Empty);
                            Clear();
                            #endregion

                        }
                        else
                        {
                            ShowValidationMessage("This side of parent is already filled. Please try to add other side!");
                            return;
                        }
                    }
                    catch (Exception ex)
                    {
                        dbTran.Rollback();
                        log.Logger.Log("txnId " + txnId + " " + ex.Message, ex.StackTrace);
                        MessageBox.Show("Registration Failed!");
                    }
                }
            }
        }

        private void Clear()
        {
            txtAddress.Text = "";
            txtContact.Text = "";
            txtName.Text = "";
            txtParentName.Text = "";
            txtSponcerId.Text = "";
            cmbGender.SelectedIndex = 0;
            cmbParentAccount.SelectedIndex = 0;
            cmbPlan.SelectedIndex = 0;
            cmbSide.SelectedIndex = 0;

            txtAccountHolderName.Text = "";
            txtAccountNo.Text = "";
            txtBankName.Text = "";
            txtBranchName.Text = "";
            txtIFSCCode.Text = "";

            lblPlanName.Text = "Plan Name";
            lblJoiningAmount.Text = "0";

        }

        private void FillComboParentId()
        {
            using (BPlanEntities ctx = new BPlanEntities())
            {
                cmbParentAccount.Items.Clear();

                var lst = ctx.Account_Master.Where(x => x.Acc_Id > 0).ToList();

                DataTable dt = new DataTable();
                dt.Columns.Add("Acc_Id");
                dt.Columns.Add("Value");

                DataRow dr = dt.NewRow();
                dr["Acc_Id"] = "--Select Parent Id--";
                dr["Value"] = 0;
                dt.Rows.Add(dr);
                foreach (var item in lst)
                {
                    DataRow drNew = dt.NewRow();
                    drNew["Acc_Id"] = item.Acc_Id;
                    drNew["Value"] = item.Acc_Id;
                    dt.Rows.Add(drNew);
                }
                cmbParentAccount.DataSource = dt;
                cmbParentAccount.DisplayMember = "Acc_Id";
                cmbParentAccount.ValueMember = "Value";

            }
        }

        private void FillComboPlan()
        {
            using (BPlanEntities ctx = new BPlanEntities())
            {
                cmbPlan.Items.Clear();
                var lst = ctx.PlanMasters.Where(x => x.PlanId > 0).ToList();
                DataTable dt = new DataTable();
                dt.Columns.Add("PlanName");
                dt.Columns.Add("PlanId");

                DataRow dr = dt.NewRow();
                dr["PlanName"] = "--Select Plan--";
                dr["PlanId"] = 0;
                dt.Rows.Add(dr);
                foreach (var item in lst)
                {
                    DataRow drNew = dt.NewRow();
                    drNew["PlanName"] = item.PlanName;
                    drNew["PlanId"] = item.PlanId;
                    dt.Rows.Add(drNew);
                }
                cmbPlan.DataSource = dt;
                cmbPlan.DisplayMember = "PlanName";
                cmbPlan.ValueMember = "PlanId";
            }
        }

        private void ShowValidationMessage(string Message)
        {
            MessageBox.Show(Message);
        }

        private void ShowValidationMessage(List<string> messages)
        {
            string strAllMessage = string.Empty;
            foreach (var message in messages)
            {
                strAllMessage += message + Environment.NewLine;
            }

            MessageBox.Show(strAllMessage);
            lstValidationMessage.Clear();
        }

        private void cmbParentAccount_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbParentAccount.SelectedIndex > 0)
            {
                using (BPlanEntities ctx = new BPlanEntities())
                {
                    int accountId = Convert.ToInt32(cmbParentAccount.Text);
                    var parent = ctx.Account_Master.Where(x => x.Acc_Id == accountId).FirstOrDefault();
                    if (parent != null)
                        lblParentAccountName.Text = parent.Acc_Name.ToString();
                    else
                    {
                        ShowValidationMessage("Select correct Parent!");
                        return;
                    }
                }
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void cmbPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbPlan.SelectedIndex > 0)
            {
                using (BPlanEntities ctx = new BPlanEntities())
                {
                    int planId = Convert.ToInt32(cmbPlan.SelectedValue);
                    var plan = ctx.PlanMasters.Where(x => x.PlanId == planId).FirstOrDefault();
                    if (plan != null)
                    {
                        lblPlanName.Text = plan.PlanName.ToString();
                        lblJoiningAmount.Text = plan.JoiningAmount.ToString();
                    }
                    else
                    {
                        ShowValidationMessage("Select correct Plan!");
                        return;
                    }
                }
            }
        }

    }
}

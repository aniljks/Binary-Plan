﻿using BinaryPlan.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BinaryPlan.MainForm
{
    public partial class Settings : Form
    {
        public Settings()
        {
            InitializeComponent();
            DisplayFreequency();
        }

        public void DisplayFreequency()
        {
            using (BPlanEntities ctx = new BPlanEntities())
            {

                var setting = ctx.Settings.Where(x => x.SettingKey == "PaymentFreequency").FirstOrDefault();
                if (setting != null)
                {
                    lblCurrentFreequency.Text = setting.SettingValue;
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cmbSessionFreequancy.SelectedIndex <= 0)
            {
                MessageBox.Show("Select Payment freequency !!");
                return;
            }

            using (BPlanEntities ctx = new BPlanEntities())
            {
                var setting = ctx.Settings.Where(x => x.SettingKey == "PaymentFreequency").FirstOrDefault();
                if (setting == null)
                {
                    ctx.Settings.Add(new Setting() { SettingKey = "PaymentFreequency", SettingValue = cmbSessionFreequancy.Text });
                    ctx.SaveChanges();
                }
                else
                {
                    setting.SettingValue = cmbSessionFreequancy.Text;
                    ctx.Entry(setting).State = System.Data.Entity.EntityState.Modified;
                    ctx.SaveChanges();
                }
            }
            MessageBox.Show("Settings updated !!");
        }
    }
}

﻿namespace BinaryPlan.MainForm
{
    partial class Settings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.cmbSessionFreequancy = new System.Windows.Forms.ComboBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblCurrentFreequency = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(53, 88);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(154, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Generate Payment Freequency";
            // 
            // cmbSessionFreequancy
            // 
            this.cmbSessionFreequancy.FormattingEnabled = true;
            this.cmbSessionFreequancy.Items.AddRange(new object[] {
            "--Select--",
            "Week",
            "Month",
            "Year"});
            this.cmbSessionFreequancy.Location = new System.Drawing.Point(222, 85);
            this.cmbSessionFreequancy.Name = "cmbSessionFreequancy";
            this.cmbSessionFreequancy.Size = new System.Drawing.Size(121, 21);
            this.cmbSessionFreequancy.TabIndex = 10;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(222, 169);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 12;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblCurrentFreequency
            // 
            this.lblCurrentFreequency.AutoSize = true;
            this.lblCurrentFreequency.Location = new System.Drawing.Point(222, 128);
            this.lblCurrentFreequency.Name = "lblCurrentFreequency";
            this.lblCurrentFreequency.Size = new System.Drawing.Size(63, 13);
            this.lblCurrentFreequency.TabIndex = 13;
            this.lblCurrentFreequency.Text = "Freequency";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(61, 128);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(146, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Current payment Freequency ";
            // 
            // Settings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(555, 446);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblCurrentFreequency);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cmbSessionFreequancy);
            this.Name = "Settings";
            this.Text = "Settings";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbSessionFreequancy;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblCurrentFreequency;
        private System.Windows.Forms.Label label1;

    }
}
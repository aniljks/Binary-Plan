﻿using BinaryPlan.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BinaryPlan.Report
{
    public partial class FindPairDetails : Form
    {
        public FindPairDetails()
        {
            InitializeComponent();
        }

        List<string> lstNodes = new List<string>();
        /// <summary>
        /// This is perfect method for count node at level and pair
        /// </summary>
        /// <param name="tree"></param>
        /// <param name="level"></param>
        public void printGivenLevel(int tree, int level)
        {

            using (BPlanEntities ctx = new BPlanEntities())
            {
                if (tree == 0)
                    return;

                if (level == 1)
                    lstNodes.Add(tree.ToString());
                else if (level > 1)
                {
                    var pnode = ctx.Account_Details.Where(x => x.Acc_Id == tree).FirstOrDefault();
                    var lnode = ctx.Account_Details.Where(x => x.Acc_Id == pnode.Left_Id).FirstOrDefault();
                    var rnode = ctx.Account_Details.Where(x => x.Acc_Id == pnode.Right_Id).FirstOrDefault();
                    if (pnode != null)
                    {
                        if (pnode.Left_Id != null)
                            printGivenLevel(pnode.Left_Id.Value, level - 1);

                        if (pnode.Right_Id != null)
                            printGivenLevel(pnode.Right_Id.Value, level - 1);
                    }
                }
            }


        }

        private void btnCheckPairs_Click(object sender, EventArgs e)
        {
            lstNodes.Clear();
            txtNodes.Text = "";
            printGivenLevel(Convert.ToInt16(txtAccountId.Text), Convert.ToInt16(txtLevel.Text));
            txtNodes.Text = "Total id's at level  " + txtLevel.Text + " is : " + lstNodes.Count + Environment.NewLine;
            int totalPairs = lstNodes.Count / 2;
            txtNodes.Text += "Total Pair at level   " + txtLevel.Text + " is  : " + totalPairs.ToString() + Environment.NewLine;
            txtNodes.Text += "Account Id's at level   " + txtLevel.Text + " are : " + Environment.NewLine;
            foreach (var item in lstNodes)
            {
                txtNodes.Text += "  " + item + " , ";
            }



            if (lstNodes.Count == 0)
                txtNodes.Text = "0";
        }
    }
}

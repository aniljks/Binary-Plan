﻿namespace BinaryPlan.Report
{
    partial class FindPairDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAccountId = new System.Windows.Forms.TextBox();
            this.txtLevel = new System.Windows.Forms.TextBox();
            this.btnCheckPairs = new System.Windows.Forms.Button();
            this.txtNodes = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(260, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "Account Id";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(279, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "Level";
            // 
            // txtAccountId
            // 
            this.txtAccountId.Location = new System.Drawing.Point(339, 39);
            this.txtAccountId.Name = "txtAccountId";
            this.txtAccountId.Size = new System.Drawing.Size(100, 20);
            this.txtAccountId.TabIndex = 15;
            // 
            // txtLevel
            // 
            this.txtLevel.Location = new System.Drawing.Point(339, 74);
            this.txtLevel.Name = "txtLevel";
            this.txtLevel.Size = new System.Drawing.Size(100, 20);
            this.txtLevel.TabIndex = 14;
            // 
            // btnCheckPairs
            // 
            this.btnCheckPairs.Location = new System.Drawing.Point(339, 117);
            this.btnCheckPairs.Name = "btnCheckPairs";
            this.btnCheckPairs.Size = new System.Drawing.Size(75, 23);
            this.btnCheckPairs.TabIndex = 13;
            this.btnCheckPairs.Text = "Check Pairs";
            this.btnCheckPairs.UseVisualStyleBackColor = true;
            this.btnCheckPairs.Click += new System.EventHandler(this.btnCheckPairs_Click);
            // 
            // txtNodes
            // 
            this.txtNodes.Location = new System.Drawing.Point(251, 182);
            this.txtNodes.Multiline = true;
            this.txtNodes.Name = "txtNodes";
            this.txtNodes.Size = new System.Drawing.Size(314, 167);
            this.txtNodes.TabIndex = 18;
            // 
            // FindPairDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(916, 492);
            this.Controls.Add(this.txtNodes);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtAccountId);
            this.Controls.Add(this.txtLevel);
            this.Controls.Add(this.btnCheckPairs);
            this.Name = "FindPairDetails";
            this.Text = "FindPairDetails";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtAccountId;
        private System.Windows.Forms.TextBox txtLevel;
        private System.Windows.Forms.Button btnCheckPairs;
        private System.Windows.Forms.TextBox txtNodes;
    }
}
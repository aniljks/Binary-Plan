﻿using BinaryPlan.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BinaryPlan.Report
{
    public partial class FindAdvisorDetail : Form
    {
        public FindAdvisorDetail()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            using (BPlanEntities ctx = new BPlanEntities())
            {
                int accId = 0;
                if (!string.IsNullOrEmpty(txtAccountId.Text))
                    accId = Convert.ToInt16(txtAccountId.Text);

                string accName = string.Empty;
                if (!string.IsNullOrEmpty(txtAccountName.Text))
                    accName = txtAccountName.Text;

                DateTime dtDOJFrom = dtpDOJFrom.Value;
                DateTime dtDOJTo = dtpDOJTo.Value;

                //var accounts = ctx.Account_Master.Where(x => (x.Acc_Id == accId || x.Acc_Name.Contains(accName))).ToList();

                var accounts = (from am in ctx.Account_Master
                                join ad in ctx.Account_Details
                                on am.Acc_Id equals ad.Acc_Id
                                where (am.Acc_Id == accId || am.Acc_Name.Contains(accName))
                                select new
                                {
                                    am.Acc_Id,
                                    am.Acc_Name,
                                    am.Acc_Address,
                                    am.Acc_phoneNo,
                                    am.DOB,
                                    am.City,
                                    am.EmailId,
                                    am.Gender,
                                    ad.DOJ
                                }).ToList();

                var accountsDOJ = accounts.Where(x => x.DOJ >= dtDOJFrom && x.DOJ <= dtDOJTo).ToList();

                #region Comment
                //List<Account_Master> accountsFound = new List<Account_Master>();
                //List<Account_Master> accountsFoundWithDOJ = new List<Account_Master>();
                //bool isDOJFiltered = false;
                //foreach (var account in accounts)
                //{
                //    var acc = account.Account_Details.Where(x => x.DOJ >= dtDOJFrom && x.DOJ <= dtDOJTo).FirstOrDefault();
                //    if (acc != null)
                //    {
                //        isDOJFiltered = true;
                //        accountsFoundWithDOJ.Add(account);
                //    }
                //    else
                //    {
                //        accountsFound.Add(account);
                //    }
                //}

                //if (isDOJFiltered)
                //    dgAdvisorDetails.DataSource = accountsFoundWithDOJ;
                //else
                //    dgAdvisorDetails.DataSource = accountsFound;
                #endregion

                dgAdvisorDetails.DataSource = accountsDOJ;
            }
        }
    }
}

﻿using BinaryPlan.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BinaryPlan.Report
{
    public partial class AccountIncome : Form
    {
        public AccountIncome()
        {
            InitializeComponent();
        }

        private void AccountIncome_Load(object sender, EventArgs e)
        {
            FillComboIncomeType();
        }

        private void FillComboIncomeType()
        {
            using (BPlanEntities ctx = new BPlanEntities())
            {
                cmbIncomeType.Items.Clear();
                var lst = ctx.Income_Type.Where(x => x.IncomeId > 0).ToList();
                DataTable dt = new DataTable();
                dt.Columns.Add("Name");
                dt.Columns.Add("Id");

                DataRow dr = dt.NewRow();
                dr["Name"] = "--Select Income--";
                dr["Id"] = 0;
                dt.Rows.Add(dr);
                foreach (var item in lst)
                {
                    DataRow drNew = dt.NewRow();
                    drNew["Name"] = item.IncomeName;
                    drNew["Id"] = item.IncomeId;
                    dt.Rows.Add(drNew);
                }
                cmbIncomeType.DataSource = dt;
                cmbIncomeType.DisplayMember = "Name";
                cmbIncomeType.ValueMember = "Id";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int accid = 0;
            using (BPlanEntities ctx = new BPlanEntities())
            {

                if (string.IsNullOrEmpty(txtAccountId.Text))
                {
                    MessageBox.Show("Enter Account Id!");
                    return;
                }
                else
                {
                    accid = Convert.ToInt16(txtAccountId.Text);
                    var acc = ctx.Account_Master.Where(x => x.Acc_Id == accid).FirstOrDefault();
                    if (acc == null)
                    {
                        MessageBox.Show("Enter correct Account Id!");
                        return;
                    }
                }

                if (cmbIncomeType.SelectedIndex == 0)
                {
                    var paymentDetails = ctx.Payment_master.Where(x => x.Acc_Id == accid).ToList();

                    dgIncome.DataSource = paymentDetails;
                }
                else
                {
                    int incomeTypeId = Convert.ToInt16(cmbIncomeType.SelectedValue);
                    var paymentDetails = ctx.Payment_master.Where(x => x.Acc_Id == accid && x.Income_Type == incomeTypeId).ToList();
                    dgIncome.DataSource = paymentDetails;
                }
                
                Clear();

            }
        }

        public void Clear()
        {
            txtAccountId.Text = "";
            cmbIncomeType.SelectedIndex = 0;

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            Clear();
        }
    }
}

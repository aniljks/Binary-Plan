﻿namespace BinaryPlan.Report
{
    partial class AccountIncome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAccount = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtAccountId = new System.Windows.Forms.TextBox();
            this.cmbIncomeType = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.dgIncome = new System.Windows.Forms.DataGridView();
            this.btnReset = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgIncome)).BeginInit();
            this.SuspendLayout();
            // 
            // lblAccount
            // 
            this.lblAccount.AutoSize = true;
            this.lblAccount.Location = new System.Drawing.Point(130, 71);
            this.lblAccount.Name = "lblAccount";
            this.lblAccount.Size = new System.Drawing.Size(87, 13);
            this.lblAccount.TabIndex = 0;
            this.lblAccount.Text = "Enter Account Id";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(115, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Select Income Type";
            // 
            // txtAccountId
            // 
            this.txtAccountId.Location = new System.Drawing.Point(236, 71);
            this.txtAccountId.Name = "txtAccountId";
            this.txtAccountId.Size = new System.Drawing.Size(191, 20);
            this.txtAccountId.TabIndex = 2;
            // 
            // cmbIncomeType
            // 
            this.cmbIncomeType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbIncomeType.FormattingEnabled = true;
            this.cmbIncomeType.Location = new System.Drawing.Point(236, 109);
            this.cmbIncomeType.Name = "cmbIncomeType";
            this.cmbIncomeType.Size = new System.Drawing.Size(191, 21);
            this.cmbIncomeType.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(236, 164);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Show Income";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dgIncome
            // 
            this.dgIncome.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgIncome.Location = new System.Drawing.Point(31, 219);
            this.dgIncome.Name = "dgIncome";
            this.dgIncome.Size = new System.Drawing.Size(862, 241);
            this.dgIncome.TabIndex = 5;
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(342, 164);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(85, 23);
            this.btnReset.TabIndex = 6;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // AccountIncome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(905, 486);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.dgIncome);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.cmbIncomeType);
            this.Controls.Add(this.txtAccountId);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblAccount);
            this.Name = "AccountIncome";
            this.Text = "AccountIncome";
            this.Load += new System.EventHandler(this.AccountIncome_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgIncome)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAccount;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtAccountId;
        private System.Windows.Forms.ComboBox cmbIncomeType;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dgIncome;
        private System.Windows.Forms.Button btnReset;
    }
}
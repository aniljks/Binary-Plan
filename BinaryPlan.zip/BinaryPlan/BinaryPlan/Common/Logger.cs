﻿using BinaryPlan.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BinaryPlan.Common
{
    public class Logger
    {
        public static void Log(string logMessage, string stackTrace)
        {
            using (BPlanEntities ctx = new BPlanEntities())
            {
                ctx.Loggers.Add(new Data.Logger()
                {
                    LogDate = DateTime.Now.Date,
                    LogMessage = logMessage,
                    StackTrace = stackTrace
                });
                ctx.SaveChanges();
            }
        }
    }
}
